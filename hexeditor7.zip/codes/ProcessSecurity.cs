﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace hexeditor7.codes
{
    internal class ProcessSecurity
    {
        private const int PROCESS_MITIGATION_POLICY_DLL_INJECTION = 0x0000000A;
        private const int PROCESS_DEP_ENABLE = 0x00000001;

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool SetProcessMitigationPolicy(
            int mitigationPolicy,
            IntPtr lpBuffer,
            int dwLength
        );

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool SetProcessDEPPolicy(
            int dwFlags
        );

        public static bool EnableDLLInjectionProtection()
        {
            // Set process mitigation policy for DLL injection protection
            PROCESS_MITIGATION_POLICY policy = new PROCESS_MITIGATION_POLICY
            {
                Enable = 1 // Enable DLL injection protection
            };

            int size = Marshal.SizeOf(policy);
            IntPtr policyPtr = Marshal.AllocHGlobal(size);
            Marshal.StructureToPtr(policy, policyPtr, false);

            bool result = SetProcessMitigationPolicy(PROCESS_MITIGATION_POLICY_DLL_INJECTION, policyPtr, size);

            Marshal.FreeHGlobal(policyPtr);

            return result;
        }

        public static bool EnableDEP()
        {// Enable Data Execution Prevention (DEP)
            bool result = SetProcessDEPPolicy(PROCESS_DEP_ENABLE);
            if (!result)
            {
                string errorCode = Marshal.GetLastWin32Error().ToString();
                Console.WriteLine($"Failed to enable DEP. Error code: {errorCode}");
            }
            return result;
        }

        // Structure for PROCESS_MITIGATION_POLICY
        [StructLayout(LayoutKind.Sequential)]
        private struct PROCESS_MITIGATION_POLICY
        {
            public int Enable;
        }
    }
}
