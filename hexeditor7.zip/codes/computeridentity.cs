﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Management; // WMI를 사용하기 위해 필요
//using System.Net.NetworkInformation; // MAC 주소를 얻기 위해 필요
//using Microsoft.Win32; // 레지스트리 접근을 위해 필요
using System.Collections.Generic;

namespace hexeditor7.codes
{
    internal class Computeridentity
    {
        /// <summary>
        /// CPU의 ProcessorId 또는 SerialNumber를 가져옵니다.
        /// (일반적으로 SerialNumber는 빈 경우가 많으므로 ProcessorId를 주로 사용합니다.)
        /// </summary>
        public static string GetCpuId()
        {
            try
            {
                using (ManagementObjectSearcher mos = new ManagementObjectSearcher("SELECT ProcessorId, Name FROM Win32_Processor"))
                {
                    foreach (ManagementObject mo in mos.Get())
                    {
                        // ProcessorId는 CPU를 식별하는 데 사용될 수 있지만, 제조사에 따라 고유하지 않을 수도 있습니다.
                        if (mo["ProcessorId"] != null)
                        {
                            return mo["ProcessorId"].ToString();
                        }
                        // SerialNumber는 대부분의 CPU에서 비어있습니다.
                        // else if (mo["SerialNumber"] != null) {
                        //    return mo["SerialNumber"].ToString();
                        // }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error getting CPU ID: {ex.Message}");
            }
            return "N/A";
        }

        /// <summary>
        /// 메인보드(BaseBoard)의 일련번호를 가져옵니다.
        /// </summary>
        public static string GetMotherboardSerialNumber()
        {
            try
            {
                using (ManagementObjectSearcher mos = new ManagementObjectSearcher("SELECT SerialNumber FROM Win32_BaseBoard"))
                {
                    foreach (ManagementObject mo in mos.Get())
                    {
                        if (mo["SerialNumber"] != null)
                        {
                            return mo["SerialNumber"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error getting Motherboard Serial Number: {ex.Message}");
            }
            return "N/A";
        }

        /// <summary>
        /// BIOS의 일련번호를 가져옵니다.
        /// </summary>
        public static string GetBiosSerialNumber()
        {
            try
            {
                using (ManagementObjectSearcher mos = new ManagementObjectSearcher("SELECT SerialNumber FROM Win32_BIOS"))
                {
                    foreach (ManagementObject mo in mos.Get())
                    {
                        if (mo["SerialNumber"] != null)
                        {
                            return mo["SerialNumber"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error getting BIOS Serial Number: {ex.Message}");
            }
            return "N/A";
        }

        /// <summary>
        /// 첫 번째 물리적 디스크 드라이브의 일련번호를 가져옵니다.
        /// </summary>
        public static string GetDiskDriveSerialNumber()
        {
            try
            {
                using (ManagementObjectSearcher mos = new ManagementObjectSearcher("SELECT SerialNumber FROM Win32_DiskDrive"))
                {
                    // 여러 디스크가 있을 수 있으므로 첫 번째 것만 가져옵니다.
                    foreach (ManagementObject mo in mos.Get())
                    {
                        if (mo["SerialNumber"] != null)
                        {
                            return mo["SerialNumber"].ToString().Trim(); // 공백 제거
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error getting Disk Drive Serial Number: {ex.Message}");
            }
            return "N/A";
        }

        /// <summary>
        /// 시스템의 UUID (Universally Unique Identifier)를 가져옵니다.
        /// (하드웨어로부터 파생된 고유 식별자)
        /// </summary>
        public static string GetSystemUuid()
        {
            try
            {
                using (ManagementObjectSearcher mos = new ManagementObjectSearcher("SELECT UUID FROM Win32_ComputerSystemProduct"))
                {
                    foreach (ManagementObject mo in mos.Get())
                    {
                        if (mo["UUID"] != null)
                        {
                            return mo["UUID"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error getting System UUID: {ex.Message}");
            }
            return "N/A";
        }

        /// <summary>
        /// 활성 네트워크 어댑터의 MAC 주소를 가져옵니다.
        /// 여러 MAC 주소가 있을 수 있으므로 리스트로 반환합니다.
        /// </summary>
        public static List<string> GetMacAddresses()
        {
            List<string> macAddresses = new List<string>();
            try
            {
                foreach (NetworkInterface nic in NetworkInterface.GetAllNetworkInterfaces())
                {
                    // 물리적 네트워크 어댑터 (이더넷, Wi-Fi)만 고려
                    if (nic.OperationalStatus == OperationalStatus.Up &&
                        (nic.NetworkInterfaceType == NetworkInterfaceType.Ethernet ||
                         nic.NetworkInterfaceType == NetworkInterfaceType.Wireless80211) &&
                        !string.IsNullOrEmpty(nic.GetPhysicalAddress().ToString()))
                    {
                        macAddresses.Add(
                            BitConverter.ToString(nic.GetPhysicalAddress().GetAddressBytes()).Replace("-", ":")
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error getting MAC Address: {ex.Message}");
            }
            return macAddresses;
        }

        /// <summary>
        /// Windows 설치 시 생성되는 고유한 Machine GUID를 가져옵니다.
        /// (Windows OS 설치에 따라 고유하며, 재설치 시 변경될 수 있습니다.)
        /// </summary>
        public static string GetMachineGuid()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Cryptography"))
                {
                    if (key != null)
                    {
                        object value = key.GetValue("MachineGuid");
                        if (value != null)
                        {
                            return value.ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error getting Machine GUID: {ex.Message}");
            }
            return "N/A";
        }

        public string getidentity()   //string temp =  computeridentity . getidentity() 
        {
            StringBuilder sb= new StringBuilder();
            //sb.Append("--- 컴퓨터 식별 정보 ---");
            sb.Append($"CPU ID: {GetCpuId()},");
            sb.Append($"Motherboard Serial: {GetMotherboardSerialNumber()},");
            sb.Append($"BIOS Serial: {GetBiosSerialNumber()},");
            sb.Append($"Disk Drive Serial: {GetDiskDriveSerialNumber()},");
            sb.Append($"System UUID: {GetSystemUuid()},");

            List<string> macs = GetMacAddresses();
            sb.Append("MAC Addresses:");
            if (macs.Count > 0)
            {
                foreach (string mac in macs)
                {
                    sb.Append($"  - {mac}");
                }
            }
            else
            {
                sb.Append("  N/A");
            }

            sb.Append($",Machine GUID: {GetMachineGuid()}");

            return sb.ToString();
        }
    }
}
