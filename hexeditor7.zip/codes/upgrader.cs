﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Policy;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;


namespace hexeditor7.codes
{
    internal class Upgrader
    {
        private Computeridentity computeridentityinstance;
        private Form1 forminstance;
        public Upgrader(Form1 form1)
        {
            forminstance = form1;
            computeridentityinstance = new Computeridentity();
        }

        public bool isdown = false;
        //first version of Upgraderoutine
        public bool allowClose = false;
        //seccond version of Upgraderoutine 2025_04_21
        //===========================================================  upgraderoutine("promaker"); =====================================================================================
        //public async void

        //public System.Windows.Forms.ProgressBar progressBar1; // 동적으로 생성할 ProgressBar
        //public System.Windows.Forms.Label progressBarlabel; // 동적으로 생성할 ProgressBar

        private bool progressdrawbool = true;

        private void WebClient_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            try
            {
                if (!progressdrawbool) return;

                progressdrawbool = false;

                if (forminstance.progressBar1 == null)
                {
                    forminstance.Invoke(new Action(() =>
                    {
                        forminstance.progressBar1 = new System.Windows.Forms.ProgressBar();
                        forminstance.progressBar1.Size = new Size((int)(forminstance.ClientSize.Width / 4), 50); // 적절한 크기 설정
                        forminstance.progressBar1.Location = new Point((forminstance.ClientSize.Width - forminstance.progressBar1.Width) / 2, (forminstance.ClientSize.Height - forminstance.progressBar1.Height) / 2); // 폼 가운데 배치
                        forminstance.progressBar1.Name = "progressBar1";
                        forminstance.progressBar1.TabIndex = 168;
                        forminstance.progressBar1.Tag = "loaded";
                        forminstance.Controls.Add(forminstance.progressBar1);
                        forminstance.progressBar1.Visible = true;
                        forminstance.progressBar1.Show();
                        forminstance.progressBar1.BringToFront();

                        forminstance.progressBarlabel = new System.Windows.Forms.Label();
                        forminstance.progressBarlabel.AutoSize = true;
                        //progressBarlabel.Location = new Point(9, 43);
                        forminstance.progressBarlabel.Location = new Point((forminstance.ClientSize.Width - forminstance.progressBar1.Width) / 2, (forminstance.ClientSize.Height - forminstance.progressBar1.Height) / 2 + 52); // 폼 가운데 배치
                        forminstance.progressBarlabel.Name = "progressBarlabel";
                        forminstance.progressBarlabel.Size = new Size(51, 15);
                        forminstance.progressBarlabel.TabIndex = 9;
                        forminstance.progressBarlabel.Text = "wish fps";
                        forminstance.progressBarlabel.Tag = "loaded";
                        forminstance.Controls.Add(forminstance.progressBarlabel);
                        forminstance.progressBarlabel.BringToFront();
                        forminstance.progressBarlabel.Visible = true;
                        forminstance.progressBarlabel.Show();
                    }));
                }

                if (forminstance.progressBar1 != null)
                {
                    forminstance.Invoke(new Action(() =>
                    {
                        forminstance.progressBar1.Visible = true;
                        forminstance.progressBar1.Show();
                        forminstance.progressBarlabel.Visible = true;
                        forminstance.progressBarlabel.Show();
                        //forminstance.progressBar1.Size = new Size((int)(forminstance.ClientSize.Width / 4), 50); // 적절한 크기 설정
                        //forminstance.progressBar1.Location = new Point((forminstance.ClientSize.Width - forminstance.progressBar1.Width) / 2, (forminstance.ClientSize.Height - forminstance.progressBar1.Height) / 2); // 폼 가운데 배치
                        forminstance.progressBar1.Maximum = (int)e.TotalBytesToReceive;
                        forminstance.progressBar1.Value = (int)e.BytesReceived;
                        forminstance.progressBar1.BringToFront();
                        //forminstance.progressBarlabel.Location= new Point((forminstance.ClientSize.Width - forminstance.progressBar1.Width) / 2, (forminstance.ClientSize.Height - forminstance.progressBar1.Height) / 2+52); // 폼 가운데 배치
                        //forminstance.progressBarlabel.BringToFront();
                        forminstance.progressBarlabel.Text = ((int)e.BytesReceived / 1000).ToString() + "kbyte /" + ((int)e.TotalBytesToReceive / 1000).ToString() + "kbyte";
                        //forminstance.errorlog(e.BytesReceived.ToString()+"/"+e.TotalBytesToReceive.ToString());
                    }));
                }

                isdown = true;



                progressdrawbool = true;
                // 다운로드 진행률 업데이트
                //progressBar1.Value = e.ProgressPercentage;
            }
            catch (Exception ex)
            {
                forminstance.errorlog("progress kind error : " + ex.ToString());
            }
        }
        
        private void WebClient_versioncheckCompleted(object sender, AsyncCompletedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    MessageBox.Show($"다운로드 완료 (오류 발생): {e.Error.Message}");
                }
                else if (!e.Cancelled)
                {
                    // DownloadStringTaskAsync를 사용했으므로 이 이벤트는 일반적으로 발생하지 않습니다.
                    // DownloadStringTaskAsync의 결과를 await하여 처리합니다.
                }

                if (forminstance.progressBar1 != null)
                {
                    forminstance.Invoke(new Action(() =>
                    {
                        forminstance.progressBar1.Visible = false;
                        forminstance.progressBarlabel.Visible = false;
                    }));
                    // 필요하다면 제거: this.Controls.Remove(progressBar1);
                }
                /*
                if (File.Exists(prfilepath))
                {
                    if (prlocation.Trim() == "")
                    {
                        System.Diagnostics.Process.Start(prfilepath);
                    }
                    else
                    {
                        System.Diagnostics.Process.Start(prfilepath, prlocation);
                        prlocation = "";
                    }
                }*/
                isdown = false;
            }
            catch (Exception ex)
            {
                forminstance.errorlog("download complete kind error : " + ex.ToString());
            }
        }

        private async void WebClient_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    MessageBox.Show($"다운로드 완료 (오류 발생): {e.Error.Message}");
                }
                else if (!e.Cancelled)
                {
                    // DownloadStringTaskAsync를 사용했으므로 이 이벤트는 일반적으로 발생하지 않습니다.
                    // DownloadStringTaskAsync의 결과를 await하여 처리합니다.
                }

                if (forminstance.progressBar1 != null)
                {
                    forminstance.Invoke(new Action(() =>
                    {
                        forminstance.progressBar1.Visible = false;
                        forminstance.progressBarlabel.Visible = false;
                    }));
                    // 필요하다면 제거: this.Controls.Remove(progressBar1);
                }

                if (File.Exists(prfilepath))
                {
                    if (prlocation.Trim() == "")
                    {
                        System.Diagnostics.Process.Start(prfilepath);

                        await Task.Delay(2000);
                        // Windows Forms 애플리케이션에서
                        //Application.Exit();
                        forminstance.Close();
                    }
                    else
                    {
                        System.Diagnostics.Process.Start(prfilepath, prlocation);
                        prlocation = "";
                    }
                }
                isdown = false;
            }
            catch (Exception ex)
            {
                forminstance.errorlog("download complete kind error : " + ex.ToString());
            }
        }
        private string prfilepath = "";
        private string prlocation = "";

        private void WebClient_ADCompleted(object sender, AsyncCompletedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    MessageBox.Show($"다운로드 완료 (오류 발생): {e.Error.Message}");
                }
                else if (!e.Cancelled)
                {
                    // DownloadStringTaskAsync를 사용했으므로 이 이벤트는 일반적으로 발생하지 않습니다.
                    // DownloadStringTaskAsync의 결과를 await하여 처리합니다.
                }

                if (forminstance.progressBar1 != null)
                {
                    forminstance.Invoke(new Action(() =>
                    {
                        forminstance.progressBar1.Visible = false;
                        forminstance.progressBarlabel.Visible = false;
                    }));
                    // 필요하다면 제거: this.Controls.Remove(progressBar1);
                }

                if (System.IO.File.Exists("ad/" + adfilename))
                {


                    try
                    {
                        //Bitmap adImage = new Bitmap("ad/" + adfilename);

                        forminstance.Invoke(new Action(() =>
                        {
                            //forminstance.errorlog("ad complete event exists adfilename : ad/" + adfilename);

                            forminstance.adpictureBox1.Image = new Bitmap("ad/" + adfilename);
                            forminstance.adpictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        }));

                        // ... 이미지 사용 코드 ...
                        //adImage.Dispose();
                    }
                    catch (Exception ex)
                    {
                        forminstance.errorlog("adfilename : " + ex.ToString());
                    }


                    //forminstance.adpictureBox1.Image = new Bitmap("ad/" + adfilename);
                    //forminstance.adpictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                }
                isdown = false;

            }
            catch (Exception ex)
            {
                forminstance.errorlog("download complete kind error : " + ex.ToString());
            }
        }

        //===========================================================  adload from coreaapp  ========================================
        //private string upgradename = "";
        public string currentFilePath = "";
        private int adtrycnt = 0;
        // private WebBrowser webBrowser;

        public string adlink = "www.coreafactory.com";
        private string adfilename = "";
        public async void adwebload()
        {//
            //Process currentProcess = Process.GetCurrentProcess(); // 프로세스의 파일 경로를 가져옴
            //currentFilePath = currentProcess.MainModule.FileName;
            //FileInfo fileInfo2 = new FileInfo(currentFilePath);
            //string upgradename = fileInfo2.Name.ToString().Replace(fileInfo2.Extension.ToString(), "");
            try
            {
                if (!AllowPortInFirewall())
                {
                    return;
                }

                //if (!Directory.Exists("ad"))
                //{
                //    Directory.CreateDirectory("ad");
                //}
                //await upgraderoutine("coreaapp", "portblocking", false, "", forminstance.richTextBox1, "jpg");
                //adfilename = adcheck("coreaapp");

                await adcheck("coreaapp");

                //if (System.IO.File.Exists("ad/" + adfilename))
                //{
                //forminstance.errorlog("adwebload function exist check adfilename : ad/" + adfilename);
                //}
            }
            catch (Exception ex)
            {
                //adtrycnt++;
                //logprint($"ad system error cnt:{adtrycnt}/5 : {ex.ToString()}");

                forminstance.errorlog($"ad system error cnt:{adtrycnt}/5 : {ex.ToString()}");

                //await Task.Delay(1000);
                //if (adtrycnt > 1)
                //{
                //    return;
                //}
                //else
                //{
                //await OpenPortInFirewall("out", "TCP");
                //    await adwebload();
                //}
            }
        }
        /*
        private async Task fileupdate(string server, string progname, string location)
        {
            try
            {
                string filePath = progname + ".exe";
                string oldFilePath = filePath;
                string newFilePath = Path.GetFileName(filePath.Replace(".exe", "_b.exe"));

                // 기존 백업 파일 삭제
                if (File.Exists(newFilePath))
                {
                    File.Delete(newFilePath);
                }

                // 현재 실행 파일 백업
                if (File.Exists(oldFilePath))
                {
                    File.Move(oldFilePath, newFilePath);
                }

                prlocation = location;
                prfilepath = filePath;

                string tempURLpromaker = $"http://www.{server}.com/data/mousehelper7/{filePath}";

                using HttpClient client = new HttpClient();

                // 파일 다운로드 스트림
                using HttpResponseMessage response = await client.GetAsync(tempURLpromaker, HttpCompletionOption.ResponseHeadersRead);
                response.EnsureSuccessStatusCode();

                long? totalBytes = response.Content.Headers.ContentLength; // 전체 파일 크기 (없을 수도 있음)

                using Stream remoteStream = await response.Content.ReadAsStreamAsync();
                using FileStream localStream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None);

                // 다운로드 진행률 추적 (선택적으로 구현 가능)
                byte[] buffer = new byte[81920];
                long totalRead = 0;
                int read;

                // 프로그레스바 최대값 설정 (알 수 없는 경우는 -1)
                if (totalBytes.HasValue)
                {
                    if (forminstance.progressBar1 != null)
                    {
                        forminstance.progressBar1.Maximum = (int)totalBytes.Value;
                    }
                }
                else
                { 
                    // 파일 크기를 모르는 경우, 최대값을 임의로 설정하거나 marquee 스타일 사용
                    forminstance.progressBar1.Style = ProgressBarStyle.Marquee;
                }

                while ((read = await remoteStream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                {
                    await localStream.WriteAsync(buffer, 0, read);
                    totalRead += read;

                    // 진행률 표시 (예: ProgressBar 업데이트)

                    if (forminstance.progressBar1 == null)
                    {
                        forminstance.Invoke(new Action(() =>
                        {
                            forminstance.progressBar1 = new System.Windows.Forms.ProgressBar();
                            forminstance.progressBar1.Size = new Size((int)(forminstance.ClientSize.Width / 4), 50); // 적절한 크기 설정
                            forminstance.progressBar1.Location = new Point((forminstance.ClientSize.Width - forminstance.progressBar1.Width) / 2, (forminstance.ClientSize.Height - forminstance.progressBar1.Height) / 2); // 폼 가운데 배치
                            forminstance.progressBar1.Name = "progressBar1";
                            forminstance.progressBar1.TabIndex = 168;
                            forminstance.progressBar1.Tag = "loaded";
                            forminstance.Controls.Add(forminstance.progressBar1);
                            forminstance.progressBar1.Visible = true;
                            forminstance.progressBar1.Show();
                            forminstance.progressBar1.BringToFront();

                            forminstance.progressBarlabel = new System.Windows.Forms.Label();
                            forminstance.progressBarlabel.AutoSize = true;
                            //progressBarlabel.Location = new Point(9, 43);
                            forminstance.progressBarlabel.Location = new Point((forminstance.ClientSize.Width - forminstance.progressBar1.Width) / 2, (forminstance.ClientSize.Height - forminstance.progressBar1.Height) / 2 + 52); // 폼 가운데 배치
                            forminstance.progressBarlabel.Name = "progressBarlabel";
                            forminstance.progressBarlabel.Size = new Size(51, 15);
                            forminstance.progressBarlabel.TabIndex = 9;
                            forminstance.progressBarlabel.Text = "wish fps";
                            forminstance.progressBarlabel.Tag = "loaded";
                            forminstance.Controls.Add(forminstance.progressBarlabel);
                            forminstance.progressBarlabel.BringToFront();
                            forminstance.progressBarlabel.Visible = true;
                            forminstance.progressBarlabel.Show();
                        }));
                    }

                    if (forminstance.progressBar1 != null)
                    {
                        forminstance.Invoke(new Action(() =>
                        {
                            forminstance.progressBar1.Visible = true;
                            forminstance.progressBar1.Show();
                            forminstance.progressBarlabel.Visible = true;
                            forminstance.progressBarlabel.Show();
                            //forminstance.progressBar1.Size = new Size((int)(forminstance.ClientSize.Width / 4), 50); // 적절한 크기 설정
                            //forminstance.progressBar1.Location = new Point((forminstance.ClientSize.Width - forminstance.progressBar1.Width) / 2, (forminstance.ClientSize.Height - forminstance.progressBar1.Height) / 2); // 폼 가운데 배치
                            //forminstance.progressBar1.Maximum = (int)e.TotalBytesToReceive;
                            //forminstance.progressBar1.Value = (int)(totalRead / 1024);

                            if (totalBytes.HasValue)
                            {
                                forminstance.progressBar1.Maximum = (int)totalBytes.Value;
                                forminstance.progressBar1.Value = (int)totalRead;
                            }

                            forminstance.progressBar1.BringToFront();
                            //forminstance.progressBarlabel.Location= new Point((forminstance.ClientSize.Width - forminstance.progressBar1.Width) / 2, (forminstance.ClientSize.Height - forminstance.progressBar1.Height) / 2+52); // 폼 가운데 배치
                            //forminstance.progressBarlabel.BringToFront();
                            forminstance.progressBarlabel.Text = ((int)totalRead / 1000).ToString() + "kbyte /" + ((int)totalBytes / 1000).ToString() + "kbyte";
                            //forminstance.errorlog(e.BytesReceived.ToString()+"/"+e.TotalBytesToReceive.ToString());
                        }));
                    }
                    //forminstance.progressBar1.Value = (int)(totalRead / 1024); // KB 단위 예시
                }

                forminstance.errorlog("파일 다운로드 완료: " + filePath);

                if (File.Exists(prfilepath))
                {
                    if (prlocation.Trim() == "")
                    {
                        System.Diagnostics.Process.Start(prfilepath);

                        await Task.Delay(2000);
                        // Windows Forms 애플리케이션에서
                        //Application.Exit();
                        forminstance.Close();
                    }
                    else
                    {
                        System.Diagnostics.Process.Start(prfilepath, prlocation);
                        prlocation = "";
                    }
                }
            }
            catch (Exception ex)
            {
                forminstance.errorlog("soundset down error : " + ex.ToString());
            }
        }
        */

        
        public async Task fileupdate(string server, string progname, string location)  // sound set list 기능 추가
        {
            // Public IP 주소 구하기  
            WebClient wc = new WebClient();
            try
            {
                string filePath = progname + ".exe";

                string oldFilePath = filePath;
                // 변경할 파일 경로 (새로운 이름 포함)
                string newFilePath = Path.GetFileName(filePath.Replace(".exe", $"_b.exe"));

                if (System.IO.File.Exists(newFilePath))
                {
                    System.IO.File.Delete(newFilePath);
                }

                if (File.Exists(oldFilePath))
                {
                    System.IO.File.Move(oldFilePath, newFilePath);
                }

                prlocation = location;
                prfilepath = filePath;

                string tempURLpromaker = $"http://www.{server}.com/data/mousehelper7/{filePath}";


                wc.DownloadProgressChanged += WebClient_DownloadProgressChanged;
                wc.DownloadFileCompleted += WebClient_DownloadFileCompleted;
                //await Task.Run(() => );
                wc.DownloadFileAsync(new Uri(tempURLpromaker), filePath);



            }
            catch (Exception ex)
            {
                forminstance.errorlog("soundset down error : " + ex.ToString());
            }
            wc.Dispose();
            wc = null;
        }
        
        public async Task adcheck(string server)
        {
            try
            {
                string temp = "";
                forminstance.Invoke(new Action(() =>
                {
                    temp = forminstance.realipaddrtxt.Text;
                }));

                Process currentProcess2 = Process.GetCurrentProcess(); // 프로세스의 파일 경로를 가져옴
                currentFilePath = currentProcess2.MainModule.FileName;
                FileInfo fileInfo2 = new FileInfo(currentFilePath);
                string upgradename2 = fileInfo2.Name.ToString().Replace(fileInfo2.Extension.ToString(), "");

                int width = forminstance.adpictureBox1.Width;
                int height = forminstance.adpictureBox1.Height;
                string wwwpath = $"/image/AD/adforprogram.php?prog={upgradename2}&adwidth={width}&adheight={height}";

                // 업그레이드 로직 수행
                string tempURLpromaker2 = $"http://www.{server}.com{wwwpath}";

                using HttpClient client = new HttpClient();
                string result = await client.GetStringAsync(tempURLpromaker2);
                string[] reslutsomeads = result.Split('&');// & YYYY-MM-DD_주소_패스.txt , 생성일

                Random randomt = new Random();
                int index = randomt.Next(reslutsomeads.Length - 1); // 랜덤한 놈으로 한놈 고름

                adfilename = reslutsomeads[index].Split(',')[0];// 파일이름
                adlink = adfilename.Split('_')[1].Split('.')[0].Replace("-", ".");
                adlink += adfilename.Split('_')[2];

                forminstance.errorlog($"adlink : {adlink} ");

                string currentTime = "0";

                if (System.IO.File.Exists(adfilename))
                {
                    fileInfo2 = new FileInfo(adfilename);
                    currentTime = fileInfo2.LastWriteTime.ToString().Substring(0, 10).Replace("-", "");
                }

                string tempURLpromaker = $"http://www.{server}.com/image/AD/image/{adfilename}";

                if (int.Parse(currentTime) < int.Parse(reslutsomeads[index].Split(',')[1].ToString()))
                {
                    try
                    {
                        //using HttpClient client = new HttpClient();
                        Stream imageStream = await client.GetStreamAsync(tempURLpromaker);

                        using (MemoryStream ms = new MemoryStream())
                        {
                            await imageStream.CopyToAsync(ms);
                            ms.Position = 0;

                            Image image = Image.FromStream(ms);
                            forminstance.Invoke(new Action(() =>
                            {
                                forminstance.adpictureBox1.Image = (Bitmap)image.Clone();
                                forminstance.adpictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                                if (forminstance.progressBar1 != null)
                                {
                                    forminstance.progressBar1.Visible = false;
                                }

                                if (forminstance.progressBarlabel != null)
                                {
                                    forminstance.progressBarlabel.Visible = false;
                                }
                                
                            }));
                        }

                    }
                    catch (HttpRequestException ex)
                    {
                        Console.WriteLine($"HTTP 요청 중 오류 발생: {ex.Message}");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"다운로드 중 예기치 않은 오류 발생: {ex.Message}");
                    }

                }

            }
            catch (Exception ex)
            {
                forminstance.errorlog("add check error : " + ex.ToString());
            }
        }
        /*
        private void adcheck2(string server)
        {
            WebClient wc = new WebClient();

            try
            {
                wc.DownloadProgressChanged += WebClient_DownloadProgressChanged;
                //wc.DownloadFileCompleted += WebClient_ADCompleted;
                //wc.DownloadDataCompleted += WebClientbyte_ADCompleted;

                Process currentProcess2 = Process.GetCurrentProcess(); // 프로세스의 파일 경로를 가져옴
                currentFilePath = currentProcess2.MainModule.FileName;
                FileInfo fileInfo2 = new FileInfo(currentFilePath);
                string upgradename2 = fileInfo2.Name.ToString().Replace(fileInfo2.Extension.ToString(), "");

                int width = forminstance.adpictureBox1.Width;
                int height = forminstance.adpictureBox1.Height;
                string wwwpath = $"/image/AD/adforprogram.php?prog={upgradename2}&adwidth={width}&adheight={height}";

                // 업그레이드 로직 수행
                string tempURLpromaker2 = $"http://www.{server}.com{wwwpath}";

                string result = wc.DownloadString(tempURLpromaker2); //Current IP Address: 119.202.146.249

                string[] reslutsomeads = result.Split('&');// & YYYY-MM-DD_주소_패스.txt , 생성일

                Random randomt = new Random();
                int index = randomt.Next(reslutsomeads.Length - 1); // 랜덤한 놈으로 한놈 고름

                adfilename = reslutsomeads[index].Split(',')[0];// 파일이름
                adlink = adfilename.Split('_')[1].Split('.')[0].Replace("-", ".");
                adlink += adfilename.Split('_')[2];

                //adlink = adfilename.Split('_')[1].Replace("-",".");
                //adlink = adfilename.Replace("." + tempadlink[tempadlink.Length - 1], "");
                //adfilename = adlink.Replace(".", "").ToString().Replace("_","1") + "." + tempadlink[tempadlink.Length - 1];
                forminstance.errorlog($"adlink : {adlink} ");

                
                //string[] reslutsomeads = result.Split('&');
                //Random randomt = new Random();
                //int index = randomt.Next(reslutsomeads.Length - 1);
                //adfilename = reslutsomeads[index].Split(',')[0];
                //string[] tempadlink = adfilename.Split('.');
                //adlink = adfilename.Replace("." + tempadlink[tempadlink.Length - 1], "");
                ////adfilename = adlink.Replace(".", "").ToString() + "." + tempadlink[tempadlink.Length - 1];
                //forminstance.errorlog($"adlink : {adlink} ");
                

                string currentTime = "0";
                //forminstance.errorlog($"===adfilename : {adfilename}\r\n============== \r\n");

                if (System.IO.File.Exists(adfilename))
                {
                    fileInfo2 = new FileInfo(adfilename);
                    currentTime = fileInfo2.CreationTime.ToString().Substring(0, 10).Replace("-", "");
                }

                string tempURLpromaker = $"http://www.{server}.com/image/AD/image/{adfilename}";

                if (int.Parse(currentTime) < int.Parse(reslutsomeads[index].Split(',')[1].ToString()))
                {
                    //await Task.Run(() => );
                    //wc.DownloadFileAsync(new Uri(tempURLpromaker), "ad/" + adfilename);
                    wc.DownloadDataCompleted += (sender, e) =>
                    {
                        try
                        {
                            if (e.Error != null)
                            {
                                forminstance.errorlog($"Image download failed: {e.Error.Message}");
                                return;
                            }
                            if (e.Cancelled)
                            {
                                forminstance.errorlog("Image download cancelled.");
                                return;
                            }

                            byte[] downloadedBytes = e.Result; // 다운로드된 바이트 배열

                            forminstance.errorlog($"Image downloaded successfully. Size: {downloadedBytes.Length} bytes");


                            if (forminstance.progressBar1 != null)
                            {
                                forminstance.Invoke(new Action(() =>
                                {
                                    forminstance.progressBar1.Visible = false;
                                    forminstance.progressBarlabel.Visible = false;
                                }));
                                // 필요하다면 제거: this.Controls.Remove(toolStripProgressBar1);
                            }

                            // 바이트 배열을 MemoryStream으로 변환
                            using (MemoryStream ms = new MemoryStream(e.Result))
                            {
                                // MemoryStream에서 Image 객체 생성 (비트맵으로 로드)
                                Image image = Image.FromStream(ms);
                                forminstance.Invoke(new Action(() =>
                                {
                                    //forminstance.errorlog("ad complete event exists adfilename : ad/" + adfilename);

                                    forminstance.adpictureBox1.Image = (Bitmap)image.Clone();
                                    forminstance.adpictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                                }));
                            }
                            //Bitmap adImage = new Bitmap("ad/" + adfilename);


                        }
                        catch (Exception ex)
                        {
                            forminstance.errorlog("adcheck error : " + ex.ToString());
                        }
                    };
                    try
                    {
                        // 바이트 배열로 다운로드
                        wc.DownloadDataAsync(new Uri(tempURLpromaker));
                        //byte[] downloadedBytes = 
                        //Console.WriteLine($"파일 내용이 변수에 성공적으로 저장되었습니다. 크기: {downloadedBytes.Length} 바이트");
                        // 이제 downloadedBytes 변수를 사용하여 원하는 작업을 수행합니다.

                        // 텍스트 파일이라면 문자열로 변환하여 다운로드
                        // string downloadedString = await client.GetStringAsync(tempURLpromaker);
                        // Console.WriteLine($"파일 내용이 변수에 성공적으로 저장되었습니다. 길이: {downloadedString.Length} 문자");
                        // 이제 downloadedString 변수를 사용하여 원하는 작업을 수행합니다.
                    }
                    catch (HttpRequestException ex)
                    {
                        Console.WriteLine($"HTTP 요청 중 오류 발생: {ex.Message}");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"다운로드 중 예기치 않은 오류 발생: {ex.Message}");
                    }

                }
                //forminstance.errorlog($"=======\r\n{result}\r\n============== \r\n");
            }
            catch (Exception ex)
            {
                forminstance.errorlog("adcheck error : " + ex.ToString());
            }

            wc.Dispose();
            wc = null;

            return;
            //return adfilename;
        }
        */
        /*
        //private WebClient wc;
        public async Task versioncheck(string server, string progname, string location)
        {
            WebClient wc = new WebClient();
            try
            {
                Process currentProcess2 = Process.GetCurrentProcess(); // 프로세스의 파일 경로를 가져옴
                currentFilePath = currentProcess2.MainModule.FileName;
                progname = Path.GetFileName(currentFilePath).Replace(".exe", "");
                //currentFilePath = Path.GetDirectoryName(currentFilePath) + "\\" + progname + ".exe";
                FileInfo fileInfo2 = new FileInfo(currentFilePath);
                //string currentTime = fileInfo2.LastWriteTime.ToString().Substring(0, 10).Replace("-", ""); //20250809 110045
                //string currentTime = fileInfo2.LastWriteTime.ToString().Replace("-", "").Replace(":","").Replace(" ", "").Replace("오전", "").Replace("오후", "").Replace("AM", "").Replace("PM", ""); //20250809 110045
                string currentTime = fileInfo2.LastWriteTime.ToString("yyyyMMddHHmmss");
                prfilepath = "";
                wc.DownloadProgressChanged += WebClient_DownloadProgressChanged;
                //wc.DownloadStringCompleted += WebClient_DownloadStringCompleted;
                wc.DownloadStringCompleted += WebClient_versioncheckCompleted;
                string temp = "";

                forminstance.Invoke(new Action(() =>
                {
                    temp = forminstance.realipaddrtxt.Text;
                }));

                //string wwwpath = $"/upgrader.php?program={progname}&directory=mousemacro"; // /data/mousemacro/
                string wwwpath = $"/upgrader.php?program={progname}&directory=mousehelper7&upgraderversion=2&realip={temp}"; // /data/mousemacro/
                // 업그레이드 로직 수행
                string tempURLpromaker = $"http://www.{server}.com{wwwpath}";// http://www.coreaapp.com/upgrader.php?program=softmouse&directory=mousemacro&upgraderversion=2"

                string result = wc.DownloadString(tempURLpromaker); //Current IP Address: 119.202.146.249
                StringBuilder sb = new StringBuilder();

                byte[] versionData = Convert.FromBase64String(result); // Display the decoded string

                string version = Encoding.UTF8.GetString(versionData);

                //DateTime.TryParse(version, out DateTime serverDate);
                //DateTime.TryParse(currentTime, out DateTime currentTimeversion);
                //if ()
                //{
                sb.Append("\r\ncurrentTime : " + currentTime + "\r\n");
                sb.Append("serverDate : " + version + "\r\n");
                sb.Append("System.DateTime.Now :" + System.DateTime.Now + "\r\n");
                    //sb.Append("currentTime : " + currentTimeversion + "\r\n");
                    //sb.Append("serverDate : " + serverDate + "\r\n");

                    forminstance.errorlog(sb.ToString());

                    if( long.Parse(currentTime) < long.Parse(version))
                    {
                        forminstance.errorlog("서버파일이 최신입니다.");
                        //DialogResult result2 = MessageBox.Show($"프로그램 {currentFilePath}의 버전 채크결과 \r\n 서버파일이 최신입니다 \r\n 업그레이드 하시겠습니까?", "업그레이드 알림", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        //if (result2 == DialogResult.Yes)
                        //{
                        fileupdate(server, progname, location);
                        //}
                        //DialogResult result2 = MessageBox.Show($"프로그램 {currentFilePath}의 버전 채크결과 \r\n 서버파일이 최신입니다 \r\n 업그레이드 합니다", "업그레이드 알림", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    }
                //}

            }
            catch (Exception ex)
            {
                forminstance.errorlog("server version check error : " + ex.ToString());
            }

            wc.Dispose();
            wc = null;
        }
        */

        public async Task versioncheck(string server, string progname, string location)
        {
            try
            {
                Process currentProcess2 = Process.GetCurrentProcess();
                currentFilePath = currentProcess2.MainModule.FileName;
                progname = Path.GetFileName(currentFilePath).Replace(".exe", "");

                FileInfo fileInfo2 = new FileInfo(currentFilePath);
                string currentTime = fileInfo2.LastWriteTime.ToString("yyyyMMddHHmmss");

                string temp = "";
                forminstance.Invoke(new Action(() =>
                {
                    temp = forminstance.realipaddrtxt.Text;
                }));
                
                string wwwpath = $"/upgrader.php?program={progname}&directory=hexeditor7&upgraderversion=2&realip={temp}";

                string tempURLpromaker = $"http://www.{server}.com{wwwpath}";

                using HttpClient client = new HttpClient();
                string result = await client.GetStringAsync(tempURLpromaker);

                byte[] versionData = Convert.FromBase64String(result);
                string version = Encoding.UTF8.GetString(versionData);

                StringBuilder sb = new StringBuilder();
                sb.AppendLine($"\r\ncurrentTime : {currentTime}");
                sb.AppendLine($"serverDate : {version}");
                sb.AppendLine($"System.DateTime.Now : {DateTime.Now}");

                forminstance.errorlog(sb.ToString());

                if (long.Parse(currentTime) < long.Parse(version))
                {
                //currentTime : 20250920132445
                //serverDate: 20250920072549

                    forminstance.errorlog("서버파일이 최신입니다.");
                    await fileupdate(server, progname, location);
                }
            }
            catch (Exception ex)
            {
                forminstance.errorlog("server version check error : " + ex);
            }
        }


        // 데이터를 Base64로 인코딩하여 간단히 암호화하는 함수
        private static string EncryptData(string plainText)
        {
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            string base64 = Convert.ToBase64String(plainTextBytes);
            return base64.Replace('+', '-').Replace('/', '_').Replace('=', '!');
        }

        public async void activecheck(string server,string progname,string devicemanaging="")
        { // activecheck("coreaapp","mousehelper7");
            try
            {
                NameValueCollection postData = new NameValueCollection();
                //string wwwpath = $"/upgrader.php?program={progname}&directory=mousemacro"; // /data/mousemacro/
                string wwwpath = $"/paying/activecheck.php"; // /data/mousemacro/   ?devicemanaging=true
                if (devicemanaging != "")
                {
                    wwwpath = wwwpath += "?devicemanaging=true&";
                }
                                                             // 업그레이드 로직 수행
                string tempURLpromaker = $"http://www.{server}.com{wwwpath}";// http://www.coreaapp.com/upgrader.php?program=softmouse&directory=mousemacro&upgraderversion=2"

                // HTTP 요청을 보낼 URL
                //string url = "https://httpbin.org/post"; // 테스트용 URL

                if (postData.Count < 1)
                {
                    postData.Add(EncryptData("realip"), EncryptData(forminstance.realipaddrtxt.Text));  // after email check
                    postData.Add(EncryptData("program"), EncryptData(progname));
                    postData.Add(EncryptData("directory"), EncryptData("hexeditor7"));
                    postData.Add(EncryptData("email"), EncryptData(forminstance.emailtxt.Text));
                    postData.Add(EncryptData("cell"), EncryptData(forminstance.cellltextBox11.Text));
                    postData.Add(EncryptData("message"), EncryptData("HelloWorld!"));


                    //sb.Append("--- 컴퓨터 식별 정보 ---");
                    postData.Add(EncryptData("CPU_ID"), EncryptData($"{Computeridentity.GetCpuId()}"));
                    postData.Add(EncryptData("Motherboard_Serial"), EncryptData($"{Computeridentity.GetMotherboardSerialNumber()}"));
                    postData.Add(EncryptData("BIOS_Serial"), EncryptData($"{Computeridentity.GetBiosSerialNumber()}"));
                    postData.Add(EncryptData("Disk_Drive_Serial"), EncryptData($"{Computeridentity.GetDiskDriveSerialNumber()}"));
                    postData.Add(EncryptData("System_UUID"), EncryptData($"{Computeridentity.GetSystemUuid()}"));

                    List<string> macs = Computeridentity.GetMacAddresses();
                    
                    StringBuilder sb = new StringBuilder();
                    if (macs.Count > 0)
                    {
                        foreach (string mac in macs)
                        {
                            sb.Append($"-{mac}");
                        }
                    }
                    else
                    {
                        sb.Append("N/A");
                    }
                    postData.Add(EncryptData("MAC_Addresses"), EncryptData(sb.ToString()));
                    postData.Add(EncryptData("Machine_GUID"), EncryptData($"{Computeridentity.GetMachineGuid()}"));
                }
                //bool success = AllowPortInFirewall();
                // WebClient 인스턴스 생성
                /*
                using (WebClient client = new WebClient())
                {
                    client.DownloadProgressChanged += WebClient_DownloadProgressChanged;
                    //wc.DownloadStringCompleted += WebClient_DownloadStringCompleted;
                    client.DownloadStringCompleted += WebClient_versioncheckCompleted;

                    // 요청에 사용할 인코딩 설정 (UTF-8 권장)
                    client.Encoding = Encoding.UTF8;

                    byte[] responseBytes = client.UploadValues(tempURLpromaker, postData);

                    // 서버 응답을 문자열로 변환하여 출력
                    string responseString = Encoding.UTF8.GetString(responseBytes);

                    forminstance.errorlog("서버 응답: \r\n"+ responseString);

                    if (responseString.IndexOf("true") >= 0 )
                    {
                        forminstance.activetimelabel25.Text = "30";
                    }
                    else
                    {
                        forminstance.activetimelabel25.Text = "0";
                    }
                }*/

                using HttpClient client = new HttpClient();
                var content = new FormUrlEncodedContent(postData.Cast<string>()
                    .Select(key => new KeyValuePair<string, string>(key, postData[key])));

                HttpResponseMessage response = await client.PostAsync(tempURLpromaker, content);
                string responseString = await response.Content.ReadAsStringAsync();

                // 로그 출력
                forminstance.errorlog("서버 응답: \r\n" + responseString);

                // 응답 처리
                forminstance.activetimelabel25.Text = responseString.Contains("true") ? "30" : "0";

            }
            catch (Exception ex) {
                forminstance.errorlog(ex.ToString());
            }
        }
        

        public void abortdownload()
        {
            try
            {/*
                if (wc != null)
                {
                    wc.CancelAsync();
                    wc.Dispose();
                }*/
            }
            catch (Exception ex)
            {
                forminstance.errorlog(ex.ToString());
            }
        }

        private bool AllowPortInFirewall()
        {
            string exePath = Process.GetCurrentProcess().MainModule.FileName;
            //exePath = Path.GetDirectoryName(exePath).ToString() + "\\" + filename;

            string filename = Path.GetFileName(exePath).ToString();
            string output = "null";
            string error = "null";

            try
            {
                //netsh advfirewall firewall show rule name="Allow MyApp Outbound" | findstr /C:"Enabled: Yes"
                // netsh http add urlacl 명령어 생성
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = "netsh";// "cctvautologin.exe"; // AutoLoginSetter.exe 경로를 지정합니다.
                psi.Arguments = $"advfirewall firewall show rule name=\"Allow {filename} Outbound\""; // 사용자 이름과 비밀번호를 인수로 전달합니다.
                                                                                                      //psi.Verb = "runas"; // 관리자 권한으로 실행합니다.
                                                                                                      // shellExecute를 사용해야 runas가 작동합니다.
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                //System.Diagnostics.Process.Start(form2Path, currentlocation);
                psi.UseShellExecute = false; // false로 변경
                psi.CreateNoWindow = true; // cmd 창 숨김

                Process process1 = new Process();
                process1.StartInfo = psi;
                process1.Start();

                output = process1.StandardOutput.ReadToEnd();
                error = process1.StandardError.ReadToEnd();

                process1.WaitForExit();

                //Process.Start(psi);
                // 결과 출력
                //forminstance.errorlog("Output: " + output);
                //forminstance.errorlog("Error: " + error);

                if (process1.ExitCode == 0)
                {
                    //forminstance.errorlog("netsh 명령어 실행 성공");
                }
                else
                {
                    //forminstance.errorlog("netsh 명령어 실행 실패");
                }

                process1.Dispose();
            }
            catch (Exception ex)
            {
                forminstance.errorlog("오류 발생: " + ex.Message);
                return false;
            }

            //forminstance.errorlog(output);
            if (!(output.Contains($"{filename}")))
            {
                try
                {
                    if (!IsAdministrator())
                    {
                        DialogResult result = MessageBox.Show($"{filename} 프로그램이 초기 설정을 위해서 \r\n" +
                            "관리자 권한으로 한번 재실행 해야합니다 \r\n" +
                            "관리자 권한으로 재실행 동의하시겠습니까? \r\n" +
                            "program need admin permision for first setting...\r\n" +
                            "would you like to agree with admin restart once ? \r\n\r\n",
                            "please agree first setting",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question);

                        if (result == DialogResult.Yes)
                        {
                            allowClose = true;
                            RestartAsAdministrator();
                            return false;
                        }
                        return false;
                    }
                    else
                    {
                        basicfirewallopen(); //2025-08-18
                        //RequestAdminAccess(filename, exePath, "none");
                    }
                }
                catch (Exception ex)
                {
                    forminstance.errorlog("오류 발생: " + ex.Message);
                }
            }

            return true;
        }

        private bool RequestAdminAccess(string filename, string exePath, string ports)
        {
            try
            {  //advfirewall firewall delete rule name=\"Allow {filename} Outbound
                int port = 8888;
                if (!int.TryParse(ports, out port))
                {
                    if (ports != "none")
                    {
                        //forminstance.listeningporttxt.Text = "8888";
                        port = 8888;
                        forminstance.errorlog("port number error so setted with 8888 port");
                    }
                }


                ProcessStartInfo psiOutbounddelete = new ProcessStartInfo
                {
                    FileName = "netsh",
                    Arguments = $"advfirewall firewall delete rule name=\"Allow {filename} Outbound\"",
                    //Verb = "runas", // 관리자 권한 요청
                    UseShellExecute = true,
                    CreateNoWindow = true
                };

                ProcessStartInfo psiInbounddelete = new ProcessStartInfo
                {
                    FileName = "netsh",
                    Arguments = $"advfirewall firewall delete rule name=\"Allow {filename} Inbound\"",
                    //Verb = "runas", // 관리자 권한 요청
                    UseShellExecute = true,
                    CreateNoWindow = true
                };


                // Process.Start(psiOutbounddelete).WaitForExit(); // 아웃바운드 실행 후 대기
                // Process.Start(psiInbounddelete).WaitForExit(); // 인바운드 실행 후 대기


                ProcessStartInfo psiInbound = new ProcessStartInfo
                {
                    FileName = "netsh",
                    Arguments = $"advfirewall firewall add rule name=\"Allow {filename} Inbound\" dir=in action=allow program=\"{exePath}\"",
                    Verb = "runas", // 관리자 권한 요청
                    UseShellExecute = true,
                    CreateNoWindow = true
                };

                ProcessStartInfo psiOutbound = new ProcessStartInfo
                {
                    FileName = "netsh",
                    Arguments = $"advfirewall firewall add rule name=\"Allow {filename} Outbound\" dir=out action=allow program=\"{exePath}\"",
                    Verb = "runas", // 관리자 권한 요청
                    UseShellExecute = true,
                    CreateNoWindow = true
                };


                //Process.Start(psiOutbound).WaitForExit(); // 아웃바운드 실행 후 대기
                //Process.Start(psiInbound).WaitForExit(); // 인바운드 실행 후 대기

                ProcessStartInfo processStartInfo = new ProcessStartInfo();


                processStartInfo.FileName = "cmd.exe";
                processStartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                processStartInfo.Verb = "runas";
                processStartInfo.CreateNoWindow = true;
                processStartInfo.UseShellExecute = false;
                processStartInfo.RedirectStandardOutput = true;
                processStartInfo.RedirectStandardInput = true;
                processStartInfo.RedirectStandardError = true;

                Process process = new Process();
                process.EnableRaisingEvents = false;
                process.StartInfo = processStartInfo;
                process.Start();


                //Process.Start("netsh", );
                //Process.Start("netsh", $"advfirewall firewall add rule name=\"Allow MyApp Inbound\" dir=in action=allow program=\"{exePath}\"");
                // 방화벽 정책 삭제 (동일한 정책이 계속 추가되는 것을 방지하기 위함)
                // 방화벽 정책 추가

                string temp = $"netsh advfirewall firewall delete rule name=\"Allow {filename} Outbound\"";

                process.StandardInput.WriteLine(temp);

                temp = $"netsh advfirewall firewall delete rule name=\"Allow {filename} Inbound\"";

                process.StandardInput.WriteLine(temp);

                temp = $"netsh advfirewall firewall add rule name=\"Allow {filename} Outbound\" dir=out action=allow program=\"{exePath}\"";

                process.StandardInput.WriteLine(temp);

                temp = $"netsh advfirewall firewall add rule name=\"Allow {filename} Inbound\" dir=in action=allow program=\"{exePath}\"";
                
                process.StandardInput.WriteLine(temp);
                /*
                temp = $"netsh advfirewall firewall add rule name = \"Allow 42 Outbound TCP for DNS from cctvcsharp\" dir=out action=allow protocol=TCP localport=42";
                process.StandardInput.WriteLine(temp);
                temp = $"netsh advfirewall firewall add rule name = \"Allow 42 Outbound UDP for DNS from cctvcsharp\" dir=out action=allow protocol=UDP localport=42";
                process.StandardInput.WriteLine(temp);
                temp = $"netsh advfirewall firewall add rule name = \"Allow 53 Outbound TCP for DNS from cctvcsharp\" dir=out action=allow protocol=TCP localport=53";
                process.StandardInput.WriteLine(temp);
                temp = $"netsh advfirewall firewall add rule name = \"Allow 53 Outbound UDP for DNS from cctvcsharp\" dir=out action=allow protocol=UDP localport=53";
                process.StandardInput.WriteLine(temp);
                */

                temp = "netsh http delete urlacl url = http://+:8888/";
                process.StandardInput.WriteLine(temp);
                temp = "netsh http delete urlacl url = http://+:80/Temporary_Listen_Addresses/";
                process.StandardInput.WriteLine(temp);
                temp = "netsh http delete urlacl url = http://*:5357/";
                process.StandardInput.WriteLine(temp);
                temp = "netsh http delete urlacl url = http://*:5358/";
                process.StandardInput.WriteLine(temp);
                temp = "netsh http delete urlacl url = http://*:2869/";
                process.StandardInput.WriteLine(temp);
                temp = "netsh http delete urlacl url = https://+:5986/wsman/";
                process.StandardInput.WriteLine(temp);
                temp = "netsh http delete urlacl url = http://+:47001/wsman/";
                process.StandardInput.WriteLine(temp);
                temp = "netsh http delete urlacl url = http://+:5985/wsman/";
                process.StandardInput.WriteLine(temp);
                temp = "netsh http delete urlacl url = https://+:443/sra_{BA195980-CD49-458b-9E23-C84EE0ADCD75}/";
                process.StandardInput.WriteLine(temp);
                temp = "netsh http delete urlacl url = http://+:10246/MDEServer/";
                process.StandardInput.WriteLine(temp);
                temp = "netsh http delete urlacl url = http://+:10247/apps/";
                process.StandardInput.WriteLine(temp);
                temp = "netsh http delete urlacl url = http://+:15099/";
                process.StandardInput.WriteLine(temp);
                temp = "netsh http delete urlacl url = https://+:3392/rdp/";
                process.StandardInput.WriteLine(temp);
                temp = "netsh http delete urlacl url = http://+:3387/rdp/";
                process.StandardInput.WriteLine(temp);
                temp = "netsh http delete urlacl url = https://+:10245/WMPNSSv4/";
                process.StandardInput.WriteLine(temp);
                temp = "netsh http delete urlacl url = http://+:10243/WMPNSSv4/";
                process.StandardInput.WriteLine(temp);
                temp = "netsh http delete urlacl url = https://*:5358/";
                process.StandardInput.WriteLine(temp);
                temp = "netsh http delete urlacl url = http://+:80/";
                process.StandardInput.WriteLine(temp);


                if (ports != "none")
                {
                    // url 예약 for 웹소켓 서비스
                    string url = "http://+:" + port + "/";  //netsh http show urlacl
                    string user = "Everyone";

                    temp = $"netsh http add urlacl url={url} user={user}";

                    process.StandardInput.WriteLine(temp);
                }

                process.StandardInput.Close();

                string output = process.StandardOutput.ReadToEnd();
                string error = process.StandardError.ReadToEnd();

                process.WaitForExit();
                process.Close();

                forminstance.errorlog(output);

                //portpermisionexcute(port.ToString());
            }
            catch (Exception ex)
            {
                forminstance.errorlog("오류 발생: " + ex.Message);
                return false;
            }

            return true;

        }

        private void basicfirewallopen()
        {
            try
            {
                string exePath = Process.GetCurrentProcess().MainModule.FileName;
                //exePath = Path.GetDirectoryName(exePath).ToString() + "\\" + filename;

                string filename = Path.GetFileName(exePath).ToString();

                ProcessStartInfo processStartInfo = new ProcessStartInfo();

                processStartInfo.FileName = "cmd.exe";
                processStartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                processStartInfo.Verb = "runas";
                processStartInfo.CreateNoWindow = true;
                processStartInfo.UseShellExecute = false;
                processStartInfo.RedirectStandardOutput = true;
                processStartInfo.RedirectStandardInput = true;
                processStartInfo.RedirectStandardError = true;

                Process process = new Process();
                process.EnableRaisingEvents = false;
                process.StartInfo = processStartInfo;
                process.Start();


                //Process.Start("netsh", );
                //Process.Start("netsh", $"advfirewall firewall add rule name=\"Allow MyApp Inbound\" dir=in action=allow program=\"{exePath}\"");
                // 방화벽 정책 삭제 (동일한 정책이 계속 추가되는 것을 방지하기 위함)
                // 방화벽 정책 추가

                string temp = $"netsh advfirewall firewall delete rule name=\"Allow {filename} Outbound\"";

                process.StandardInput.WriteLine(temp);

                temp = $"netsh advfirewall firewall delete rule name=\"Allow {filename} Inbound\"";

                process.StandardInput.WriteLine(temp);

                temp = $"netsh advfirewall firewall add rule name=\"Allow {filename} Outbound\" dir=out action=allow program=\"{exePath}\"";

                process.StandardInput.WriteLine(temp);

                temp = $"netsh advfirewall firewall add rule name=\"Allow {filename} Inbound\" dir=in action=allow program=\"{exePath}\"";

                process.StandardInput.WriteLine(temp);

                process.StandardInput.Close();

                string output = process.StandardOutput.ReadToEnd();
                string error = process.StandardError.ReadToEnd();

                process.WaitForExit();
                process.Close();

                forminstance.errorlog(output);

            }catch (Exception ex)
            {
                forminstance.errorlog("오류 발생: " + ex.Message);
            }
        }

        private static bool IsAdministrator()
        {
            WindowsIdentity identity = WindowsIdentity.GetCurrent();
            WindowsPrincipal principal = new WindowsPrincipal(identity);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }

        private static void RestartAsAdministrator()
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.UseShellExecute = true;
            startInfo.WorkingDirectory = Environment.CurrentDirectory;
            startInfo.FileName = System.Windows.Forms.Application.ExecutablePath;
            startInfo.Verb = "runas"; // Run as administrator

            Screen currentScreen = Screen.FromHandle(Process.GetCurrentProcess().MainWindowHandle);
            System.Drawing.Point newLocation = new System.Drawing.Point(currentScreen.WorkingArea.Left, currentScreen.WorkingArea.Top);

            try
            {
                Process.Start(startInfo);
            }
            catch (System.ComponentModel.Win32Exception)
            {
                // User canceled UAC prompt
                // Do nothing or handle it as needed
            }
            //Form1.ActiveForm.Location = newLocation;

            System.Windows.Forms.Application.Exit();
        }

        public bool portpermisionexcute(string port)
        {
            int portint = 8888;
            if (!int.TryParse(port, out portint))
            {
                //forminstance.listeningporttxt.Text = "8888";
                portint = 8888;
                forminstance.errorlog("port number error so setted with 8888 port");
            }

            string url = "http://+:" + portint + "/";  //netsh http show urlacl
            string user = "Everyone";

            string command = $"netsh http delete urlacl url={url}";
            string settingcommand2 = $"http add urlacl url={url} user={user}";
            string checkcommand = $"http show urlacl url={url}";
            string output = "";
            string error = "";
            //netsh http delete urlacl url = http://+:8888/
            try
            {
                // netsh http add urlacl 명령어 생성
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = "netsh";// "cctvautologin.exe"; // AutoLoginSetter.exe 경로를 지정합니다.
                psi.Arguments = checkcommand; // 사용자 이름과 비밀번호를 인수로 전달합니다.
                                              //psi.Verb = "runas"; // 관리자 권한으로 실행합니다.
                                              // shellExecute를 사용해야 runas가 작동합니다.
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                //System.Diagnostics.Process.Start(form2Path, currentlocation);
                psi.UseShellExecute = false; // false로 변경
                psi.CreateNoWindow = true; // cmd 창 숨김

                Process process = new Process();
                process.StartInfo = psi;
                process.Start();

                output = process.StandardOutput.ReadToEnd();
                error = process.StandardError.ReadToEnd();

                process.WaitForExit();

                //Process.Start(psi);
                // 결과 출력
                forminstance.errorlog("Output: " + output);
                forminstance.errorlog("Error: " + error);

                if (process.ExitCode == 0)
                {
                    forminstance.errorlog("netsh 명령어 실행 성공");
                }
                else
                {
                    forminstance.errorlog("netsh 명령어 실행 실패");
                }

                process.Dispose();

            }
            catch (Exception ex)
            {
                forminstance.errorlog("오류 발생: " + ex.Message);
                return false;
            }

            if (!(output.Contains(url) && output.Contains(user)))
            {
                try
                {
                    Process process2 = new Process();
                    ProcessStartInfo psi2 = new ProcessStartInfo();
                    psi2.Arguments = settingcommand2;
                    psi2.FileName = "netsh";// "cctvautologin.exe"; // AutoLoginSetter.exe 경로를 지정합니다.
                    psi2.Verb = "runas"; // 관리자 권한으로 실행합니다.
                                         // shellExecute를 사용해야 runas가 작동합니다.
                                         //System.Diagnostics.Process.Start(form2Path, currentlocation);
                    psi2.UseShellExecute = true; // false로 변경
                    psi2.CreateNoWindow = true; // cmd 창 숨김
                    process2.StartInfo = psi2;
                    process2.Start();


                    process2.WaitForExit();

                    // 결과 출력
                    if (process2.ExitCode == 0)
                    {
                        forminstance.errorlog("url appointment success.... ");

                    }
                    else
                    {
                        forminstance.errorlog("url appointment fail.... want host this program need runas admin...");
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    forminstance.errorlog("오류 발생: " + ex.Message);
                }
            }

            return true;
        }
    }
}
