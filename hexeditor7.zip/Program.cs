﻿using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

namespace hexeditor7
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }


        private static Assembly OnAssemblyResolve(object sender, ResolveEventArgs args)
        {
            // 로드하려는 DLL의 이름을 가져옵니다.
            string assemblyName = new AssemblyName(args.Name).Name;
            // 'MyExpectedLibrary.dll'만 로드하도록 허용합니다.
            if (IsTrustedPath(args.Name))
            {
                // 원하는 DLL의 경로를 지정하여 수동으로 로드합니다.
                //string dllPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, assemblyName);
                if (File.Exists(args.Name))
                {
                    return Assembly.LoadFrom(args.Name);
                }
            }
            // 허용되지 않은 DLL은 로드하지 않습니다.
            return null;
        }

        //Get-FileHash "D:\0020 csharp\20250502\security\security\security\bin\Debug\net8.0-windows10.0.17763.0\security.exe" -Algorithm SHA256
        //Get-FileHash "D:\0020 csharp\20250502\security\security\security\bin\Release\net8.0-windows10.0.17763.0\win-x64\publish\security.exe" -Algorithm SHA256
        // ✅ 신뢰할 수 있는 모듈 경로 목록 (화이트리스트)
        private static readonly List<string> trustedPaths = new List<string>
        {
            //@"C:\Program Files (x86)\Microsoft Visual Studio\",
            //@"D:\0020 csharp\20250502\security\security\security\bin\Debug\net8.0-windows10.0.17763.0\",
            //@"D:\0020 csharp\20250502\security\security\security\obj\Debug\net8.0-windows10.0.17763.0\",
            //@"D:\0020 csharp\20250502\security\security\",
            @"C:\Windows\System32\",
            @"C:\Program Files\dotnet\",
            Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName)
            //@"C:\Program Files\Microsoft Windows Desktop Runtime\",
            //@"C:\Program Files\Microsoft Visual Studio\2022\Professional\"
        };

        // ✅ 예상 해시 값 (예제용 SHA256 해시)  8F7B9104821F6A6CD7287C5FFC9DEE27A9C1082582169F1A9A632847381EEB13
        //private const string expectedMainHash = "8F7B9104821F6A6CD7287C5FFC9DEE27A9C1082582169F1A9A632847381EEB13"; // TODO: 실제 해시로 교체
        //private const string expectedMainHash = "YOUR_EXPECTED_HASH_HERE"; // TODO: 실제 해시로 교체
        private const string expectedMainHash = "5A163EF3E6A684505AEF803702AA948550056D5AB869480890D5564C683A752D";
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool SetDllDirectory(string lpPathName);

        public static bool Run()
        {
            //trustedPaths.Add(Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName));
            Console.WriteLine("🚀 보안 부트스트랩 시작...");

            // DLL 하이재킹 방지: 현재 디렉터리 검색 금지
            //SetDllDirectory(null);

            // 메인 EXE 무결성 검사
            string mainExePath = Process.GetCurrentProcess().MainModule.FileName;
            if (!VerifyHash(mainExePath, expectedMainHash))
            {
                //MessageBox.Show($"❌ 무결성 오류: {mainExePath}");
                //Environment.Exit(1);
            }
            int cnt = 0;
            StringBuilder sb = new StringBuilder();
            // 로드된 모든 모듈 검사
            foreach (ProcessModule module in Process.GetCurrentProcess().Modules)
            {
                string path = module.FileName;

                cnt++;

                if (!IsTrustedPath(path))
                {
                    sb.Append($"⚠️ 경고: 의심스러운 모듈 로드됨 - {path}\n");
                    //MessageBox.Show($"⚠️ 경고: 의심스러운 모듈 로드됨 - {path}");
                    // 필요 시 종료 또는 경고만 표시
                }
                else
                {
                    sb.Append($"로드된 모듈 - {path}\n");
                }
            }
            if (sb.Length > 0)
            {
                Clipboard.SetText($"✅ 보안 검사 완료 모듈갯수 {cnt} \n{sb}");
                MessageBox.Show("보안 결과가 클립보드에 복사되었습니다!", "정보");
            }
            //MessageBox.Show($"✅ 보안 검사 완료 {sb}");

            return true;
        }

        private static bool VerifyHash(string filePath, string expectedHash)
        {
            try
            {
                using var sha256 = SHA256.Create();
                byte[] hash = sha256.ComputeHash(File.ReadAllBytes(filePath));
                string actualHash = BitConverter.ToString(hash).Replace("-", "");
                return actualHash.Equals(expectedHash, StringComparison.OrdinalIgnoreCase);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"해시 검사 실패: {ex.Message}", "보안 오류");
                return false;
            }
        }

        private static bool IsTrustedPath(string filePath)
        {
            foreach (string trusted in trustedPaths)
            {
                if (filePath.StartsWith(trusted, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }



    }
}