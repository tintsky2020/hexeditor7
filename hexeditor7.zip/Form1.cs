﻿using hexeditor7.codes;
using System.Data.Common;
using System.Diagnostics;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Text;


namespace hexeditor7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Upgrader upgraderinstance;
        public string executablePathlocal = ".";
        private void Form1_Load(object sender, EventArgs e)
        {
            // 프로그램 시작 시 한 번만 호출
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            upgraderinstance = new Upgrader(this);

            beforeFormRect = this.Bounds; // 위치 + 크기 저장
            beforerich = richTextBox1.Bounds;

            initailcombobox();

            bool success = hexeditor7.Program.Run();
            PasteClipboardToRichTextBox();

            Process current = Process.GetCurrentProcess();
            string filename = current.MainModule.FileName;
            filename = Path.GetDirectoryName(filename);
            executablePathlocal = filename;

            DialogResult result = MessageBox.Show(
                "서버에 프로그램버전 및 프로그램부가정보를 채크해도 될까요?",
                "정보 채크 확인",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                // 전송 실행 코드
                emailcheckfunc();
                upgraderinstance.adwebload();
                upgraderinstance.activecheck("coreaapp", "hexeditor7");
            }

            errorlog($"{beforeFormRect.Left}+ {beforeFormRect.Top}+ {beforeFormRect.Width}+ {beforeFormRect.Height} \r\n");

            errorlog("\r\n UEFI study \r\n FAT32 format usb drive \r\n save to  /EFI/BOOT/BOOTX64.EFI  \r\n");
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // 열고 싶은 URL
            string url = "http://www.coreaapp.com/index.php?ct=bankinfo";// "http://www.COREAFACTORY.com"; // 기본 브라우저에서 URL 열기
            LinkLuancher(url);
        }

        private void LinkLuancher(string temp)
        {
            try
            {
                Process.Start(new ProcessStartInfo("cmd", $"/c start {temp}")
                {
                    CreateNoWindow = true
                });
            }
            catch (Exception ex)
            {
                errorlog("웹 브라우저를 열 수 없습니다: " + ex.Message);
            }
        }


        public void errorlog(string msg)
        {
            if (richTextBox1 == null)
            {
                MessageBox.Show(msg);
            }
            else
            {
                this.Invoke((System.Windows.Forms.MethodInvoker)delegate
                {
                    richTextBox1.AppendText(msg);
                });
            }
        }

        private void adpictureBox1_Click(object sender, EventArgs e)
        {
            try
            {
                string url = $"http://{upgraderinstance.adlink.Replace("-", "?").Replace("~", "/").Replace("%", "_")}";// "http://www.COREAFACTORY.com"; // 기본 브라우저에서 URL 열기
                string urlpath = upgraderinstance.currentFilePath.ToString();
                urlpath = urlpath.Replace(" ", "_").Replace("/", "%").Replace("\\", "%").Replace(":", "-");
                //https://smartstore.naver.com/koreafactory_net?ad=%27D:\0020_csharp\20250502\security\security\security\bin\Debug\net8.0-windows10.0.17763.0\security.exe%27
                if (!url.Contains('?'))
                {
                    url += $"?ad='{urlpath}'";
                }
                else
                {
                    url += $"\"&ad='{urlpath}'\"";
                }
                LinkLuancher(url);
            }
            catch (Exception ex)
            {
                errorlog(ex.ToString());
            }
        }

        public System.Windows.Forms.ProgressBar progressBar1;
        public System.Windows.Forms.Label progressBarlabel;

        private async Task<bool> emailcheckfunc()
        {
            try
            {

                string filePath = $"{executablePathlocal}\\config001"; // 실제 Form2.exe 파일 경로로 변경

                //string filePath = Path.Combine("./", "config001.txt"); //Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "config001.txt");
                if (System.IO.File.Exists(filePath))
                {
                    string[] value = System.IO.File.ReadAllText(filePath).Split(',');
                    // Use the retrieved ID value as needed
                    if (emailtxt.Text == "")
                    {
                        emailtxt.Text = value[0];
                        cellltextBox11.Text = value[1] ?? "";
                    }
                }

                //emailtxt.Text = "";
                //textBox13.Text = "pakata@korea.com";
                //if (listeningporttxt.Text != "")
                //{
                //listeningporttxt.Text = "8888";
                //}

                if (emailtxt.Text != null)
                {
                    // Public IP 주소 구하기
                    //WebClient wc = new WebClient();
                    // string result = wc.DownloadString("http://tintsky.cafe24.com/ip/index.php?email=" + emailtxt.Text + "&port=8888&side=server"); //Current IP Address: 119.202.146.249
                    //string ip = result.Split(':')[1].Trim();

                    using HttpClient client = new HttpClient();
                    string url = "http://tintsky.cafe24.com/ip/index.php?email=" + emailtxt.Text + "&port=8888&side=server";

                    string result = await client.GetStringAsync(url);

                    // 예: "Current IP Address: 119.202.146.249"
                    string ip = result.Split(':')[1].Trim();

                    realipaddrtxt.Text = ip;
                    //listeningporttxt.Text = result.Split(':')[2].Trim();

                    string filePath2 = $"{executablePathlocal}\\config001"; //Path.Combine("./", "config001.txt"); //string filePath = Path.Combine("./", "data001.json"); //Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
                    string contents = $"{emailtxt.Text},{cellltextBox11.Text}";//
                                                                               //,{this.Location.X},{this.Location.Y},{this.Size.Width},{this.Size.Height}";

                    try
                    {
                        System.IO.File.WriteAllText(filePath2, contents);
                        errorlog($"\r\n 파일에 내용이 성공적으로 저장되었습니다: {filePath} \r\n");
                    }
                    catch (Exception ex)
                    {
                        errorlog($"\r\n 파일 저장 중 오류 발생: {ex.Message} \r\n");
                    }
                    //portpermision(listeningporttxt.Text);
                }
            }
            catch (Exception ex)
            {
                errorlog(ex.ToString());
            }
            return true;
        }

        private void savefilebutton3_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.Filter = "모든파일 (*.*)|*.*";
            saveDialog.Title = "파일 저장";
            saveDialog.FileName = "BOOTX64.EFI";


            List<byte> allBytes = new List<byte>();

            foreach (DataGridViewRow row in hexdataGridView1.Rows)
            {
                if (row == null || row.IsNewRow) continue;

                for (int col = 0; col < 16; col++)
                {
                    var cellValue = row.Cells[col].Value?.ToString();
                    if (!string.IsNullOrWhiteSpace(cellValue) &&
                        byte.TryParse(cellValue, System.Globalization.NumberStyles.HexNumber, null, out byte b))
                    {
                        //byte valueToAdd = (b == 0x00) ? (byte)0x2E : b; // 0x2E = '.'
                        allBytes.Add(b);
                    }
                }
            }



            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if (File.Exists(saveDialog.FileName))
                    {
                        DialogResult result = MessageBox.Show(
                            "파일이 이미 존재합니다. 덮어씌우겠습니까?",
                            "알림",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Warning
                        );

                        if (result != DialogResult.Yes)
                        {
                            MessageBox.Show("덮어씌우지 않기로 했습니다.", "알림");
                            return;
                        }
                    }

                    //string textToSave = "저장할 텍스트 내용입니다.";
                    //File.WriteAllText(saveDialog.FileName, textToSave);
                    //MessageBox.Show("저장 완료!", "알림");
                    File.WriteAllBytes(saveDialog.FileName, allBytes.ToArray());
                    MessageBox.Show("파일 저장 완료: " + saveDialog.FileName);

                }
                catch (Exception ex)
                {
                    MessageBox.Show("파일 열기 중 오류 발생:\n" + ex.Message, "오류");
                }

            }
        }

        private void openfilebutton1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog
            {
                Filter = "모든 파일 (*.*)|*.*",
                Title = "파일 열기"
            };

            if (openDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // 파일 경로 확인
                    string filePath = openDialog.FileName;

                    // 파일 존재 여부 확인
                    if (File.Exists(filePath))
                    {
                        byte[] fileBytes = File.ReadAllBytes(filePath);

                        // 예시: 파일 내용을 문자열로 변환 (텍스트 파일일 경우)
                        string fileContent = System.Text.Encoding.UTF8.GetString(fileBytes);

                        MessageBox.Show("오픈 완료!\n\n내용:\n" + fileContent, "알림");

                        bytestodatagrid(fileBytes);
                    }
                    else
                    {
                        MessageBox.Show("파일이 존재하지 않습니다.", "오류");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("파일 열기 중 오류 발생:\n" + ex.Message, "오류");
                }
            }

        }

        private bool bytestodatagrid(byte[] fileBytes)
        {
            hexdataGridView1.Rows.Clear();
            hexdataGridView1.Columns.Clear();

            hexdataGridView1.EnableHeadersVisualStyles = false;
            hexdataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.Black;
            hexdataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.Lime;
            hexdataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Consolas", 9, FontStyle.Bold);
            hexdataGridView1.DefaultCellStyle.Font = new Font("Consolas", 9);
            hexdataGridView1.DefaultCellStyle.BackColor = Color.Black;
            hexdataGridView1.DefaultCellStyle.ForeColor = Color.White;
            hexdataGridView1.DefaultCellStyle.SelectionBackColor = Color.DarkGreen;
            hexdataGridView1.DefaultCellStyle.SelectionForeColor = Color.White;
            hexdataGridView1.GridColor = Color.DarkOliveGreen;
            hexdataGridView1.RowHeadersVisible = true;
            hexdataGridView1.RowHeadersWidth = 97;
            hexdataGridView1.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            hexdataGridView1.RowHeadersDefaultCellStyle.Font = new Font("Consolas", 9, FontStyle.Bold);
            hexdataGridView1.RowHeadersDefaultCellStyle.BackColor = Color.Black;
            hexdataGridView1.RowHeadersDefaultCellStyle.ForeColor = Color.Orange;

            for (int i = 0; i < 16; i++)
            {
                DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
                column.Name = $"Hex{i:X2}";
                column.HeaderText = i.ToString("X2"); // 00 ~ 0F
                column.Width = 30;
                column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                if (i > 7)
                {
                    column.DefaultCellStyle.BackColor = ColorTranslator.FromHtml("#003000");
                }
                else
                {
                    column.DefaultCellStyle.BackColor = Color.Black;
                }
                column.DefaultCellStyle.ForeColor = Color.White;
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
                hexdataGridView1.Columns.Add(column);
            }

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.Name = $"contents";
            column2.HeaderText = "contents"; // 00 ~ 0F
            column2.Width = 170;
            column2.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            column2.DefaultCellStyle.BackColor = Color.Black;
            column2.DefaultCellStyle.ForeColor = Color.White;
            column2.SortMode = DataGridViewColumnSortMode.NotSortable;
            hexdataGridView1.Columns.Add(column2);


            Encoding selectedEncoding;

            switch (comboBox1.SelectedItem.ToString())
            {
                case "UTF-8":
                    selectedEncoding = Encoding.UTF8;
                    break;
                case "ASCII":
                    selectedEncoding = Encoding.ASCII;
                    break;
                case "Unicode":
                    selectedEncoding = Encoding.Unicode;
                    break;
                case "EUC-KR":
                    selectedEncoding = Encoding.GetEncoding("euc-kr");
                    break;
                default:
                    selectedEncoding = Encoding.UTF8;
                    break;
            }


            int bytesPerRow = 16;
            int totalRows = (int)Math.Ceiling((double)fileBytes.Length / bytesPerRow);

            for (int row = 0; row < totalRows; row++)
            {
                string[] rowData = new string[]{
                     "00","00","00","00","00","00","00","00","00","00","00","00","00","00","00","00","00" };
                byte[] asciiBytes = new byte[bytesPerRow];

                int rowIndex = hexdataGridView1.Rows.Add(rowData);

                for (int col = 0; col < bytesPerRow; col++)
                {
                    int index = row * bytesPerRow + col;

                    if (index < fileBytes.Length)
                    {
                        byte b = fileBytes[index];
                        if (b != 0x00)
                        {
                            hexdataGridView1.Rows[row].Cells[col].Style.ForeColor = Color.Red;
                            hexdataGridView1.Rows[row].Cells[col].Value = b.ToString("X2");
                        }

                        rowData[col] = b.ToString("X2");//            column2.DefaultCellStyle.ForeColor = Color.White;

                        asciiBytes[col] = (byte)((b == 0x00) ? 0x2E : b);

                    }
                    else
                    {
                        rowData[col] = "";
                        asciiBytes[col] = 0x20; // 공백
                    }
                }

                // 인코딩된 문자열 추가
                string encodedText = selectedEncoding.GetString(asciiBytes);
                rowData[bytesPerRow] = "|" + encodedText + "|";


                hexdataGridView1.Rows[rowIndex].HeaderCell.Value = (row * bytesPerRow).ToString("X8");
            }

            hexdataGridView1.Refresh();

            return true;
        }

        private void initailcombobox()
        {
            comboBox1.Items.Clear();
            comboBox1.Items.Add("UTF-8");
            comboBox1.Items.Add("ASCII");
            comboBox1.Items.Add("Unicode");
            comboBox1.Items.Add("EUC-KR");
            comboBox1.SelectedIndex = 0; // 기본 선택

        }

        private string lastdllcheck = "";
        private List<string> tlines = new List<string>();
        private void PasteClipboardToRichTextBox()
        {
            Invoke(new Action(() =>
            {
                richTextBox1.Text = "";
            }));

            string[] lines = lastdllcheck.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
            tlines.Clear();
            foreach (string s in lines)
            {
                string ss = s.Split("\\").Last().Trim().ToLower();
                if (ss == "") continue;
                tlines.Add(ss);
                //errorlog(ss+"\r\n");
            }
            string buffer = "";

            //if (Clipboard.ContainsText(TextDataFormat.Rtf))
            //{
            //    loginpage_dllcheck_richTextBox5.Rtf += Clipboard.GetText(TextDataFormat.Rtf);
            //}

            if (Clipboard.ContainsText(TextDataFormat.Text))
            {
                buffer = Clipboard.GetText(TextDataFormat.Text);
                //loginpage_dllcheck_richTextBox5.Text += Clipboard.GetText(TextDataFormat.Text);
            }
            else
            {
                MessageBox.Show("클립보드에 붙여넣을 텍스트가 없습니다.");
            }

            string[] clipboardlines = buffer.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
            foreach (string s in clipboardlines)
            {
                string trimmed = s.Split("\\").Last().Trim(); // 앞뒤 공백 제거
                if (trimmed == "") continue;

                //if (tlines.Any(tlines => tlines.Split("\\").Last().Trim().Contains(trimmed, StringComparison.OrdinalIgnoreCase)))
                if (List_Include(trimmed.ToLower()))
                {
                    AppendColoredText(s + "\r\n", Color.Black);
                }
                else
                {
                    AppendColoredText(s + "\r\n", Color.Red);
                }
            }

            Invoke(new Action(() =>
            {
                lastdllcheck = richTextBox1.Text;
            }));
        }

        private bool List_Include(string s)
        {
            foreach (string tt in tlines)
            {
                if (tt.Contains(s))
                {
                    //AppendColoredText(tt + " : " +s + "\r\n", Color.Black);
                    return true;
                }
            }
            //AppendColoredText("        : " + s + "\r\n", Color.Red);
            return false;
        }

        public void AppendColoredText(string newText, Color color)
        {
            Invoke(new Action(() =>
            {
                // 현재 텍스트의 끝 위치를 구합니다.
                richTextBox1.SelectionStart = richTextBox1.TextLength;
                // 새로 추가될 텍스트에 적용할 색상을 설정합니다.
                richTextBox1.SelectionColor = color;
                // 새로운 텍스트를 추가합니다.
                richTextBox1.AppendText(newText);
                // 다음 텍스트 추가를 위해 서식을 기본 색상으로 되돌립니다.
                richTextBox1.SelectionColor = richTextBox1.ForeColor;
            }));
        }

        private Rectangle beforeFormRect = new Rectangle(new Point(12, 436), new Size(834, 47));
        private Rectangle beforerich = new Rectangle(new Point(12, 436), new Size(834, 47));
        private void logtogglebutton2_Click(object sender, EventArgs e)
        {
            //834,87
            if (richTextBox1.Width == beforerich.Width)
            {
                // 확대: 폼 너비의 90%까지 확장
                richTextBox1.Width = (int)(this.ClientSize.Width * 0.9);
                richTextBox1.Height = (int)(this.ClientSize.Height * 1);
                richTextBox1.Top = 0;
                richTextBox1.Left = 0;
                richTextBox1.BringToFront();
                richTextBox1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
                logtogglebutton2.Text = "🔽 collapse Log";
                logtogglebutton2.BringToFront();
            }
            else
            {
                // 축소: 원래 크기로 복원 (예: 300px)     beforerich      richTextBox1
                this.Bounds = beforeFormRect;

                richTextBox1.Width = beforerich.Width;
                richTextBox1.Height = beforerich.Height;
                richTextBox1.Top = beforerich.Top;
                richTextBox1.Left = beforerich.Left;
                richTextBox1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
                logtogglebutton2.Text = "🔍 expand log";

            }
        }

        private void selfdllcheckbutton2_Click(object sender, EventArgs e)
        {
            bool success = hexeditor7.Program.Run();

            PasteClipboardToRichTextBox();
        }

        private void hexdataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            int sum = 0;

            if (hexdataGridView1.SelectedCells.Count > 0)
            {
                // 첫 번째 선택된 셀 기준
                DataGridViewCell cell = hexdataGridView1.SelectedCells[0];

                int rowIndex = cell.RowIndex;
                int columnIndex = cell.ColumnIndex;

                // 주소 텍스트박스에 행 번호 → 주소로 변환 (예: 16바이트 단위)
                int address = rowIndex * 16;
                addresstextBox2.Text = address.ToString("X7"); // 16진수 주소 표시

                // 바이트 인덱스 텍스트박스에 전체 인덱스 표시
                int byteIndex = rowIndex * 16 + columnIndex;
                //bytesindextextBox1.Text = byteIndex.ToString();
                bytesindextextBox1.Text = columnIndex.ToString();

                hexbuffertextBox1.Text = hexdataGridView1.SelectedCells[0].Value.ToString();

                sum += CalculateChecksumint(hexdataGridView1.Rows[rowIndex]);

                checksumtextBox2.Text = sum.ToString("X2");
            }

            hexbuffertextBox1.Focus();
            hexbuffertextBox1.SelectAll();

        }

        private void modifydatabutton2_Click(object sender, EventArgs e)
        {
            if (hexdataGridView1.SelectedCells.Count > 0)
            {
                var cell = hexdataGridView1.SelectedCells[0];
                int rowIndex = cell.RowIndex;

                // 1. 셀 값 수정
                cell.Value = hexbuffertextBox1.Text;

                // 2. 해당 행의 바이트 수집
                List<byte> byteList = new List<byte>();
                for (int col = 0; col < hexdataGridView1.ColumnCount - 1; col++) // 마지막 칼럼 제외
                {
                    var value = hexdataGridView1.Rows[rowIndex].Cells[col].Value?.ToString();
                    if (!string.IsNullOrWhiteSpace(value) && byte.TryParse(value, System.Globalization.NumberStyles.HexNumber, null, out byte b))
                    {
                        byteList.Add((byte)((b == 0x00) ? 0x2E : b));
                    }
                    else
                    {
                        byteList.Add(0x20); // 공백 대체
                    }
                }

                // 3. 인코딩 선택
                Encoding selectedEncoding = Encoding.UTF8;

                // 콤보박스에서 선택된 인코딩 결정
                switch (comboBox1.SelectedItem?.ToString())
                {
                    case "ASCII":
                        selectedEncoding = Encoding.ASCII;
                        break;
                    case "Unicode":
                        selectedEncoding = Encoding.Unicode;
                        break;
                    case "EUC-KR":
                        selectedEncoding = Encoding.GetEncoding("euc-kr");
                        break;
                    case "UTF-8":
                        selectedEncoding = Encoding.UTF8;
                        break;
                    default:
                        selectedEncoding = Encoding.UTF8;
                        break;
                }

                // 4. 문자열로 변환 후 마지막 셀에 반영
                string encodedText = selectedEncoding.GetString(byteList.ToArray());
                hexdataGridView1.Rows[rowIndex].Cells[hexdataGridView1.ColumnCount - 1].Value = "|" + encodedText + "|";
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Encoding selectedEncoding = Encoding.UTF8;

            // 콤보박스에서 선택된 인코딩 결정
            switch (comboBox1.SelectedItem?.ToString())
            {
                case "ASCII":
                    selectedEncoding = Encoding.ASCII;
                    break;
                case "Unicode":
                    selectedEncoding = Encoding.Unicode;
                    break;
                case "EUC-KR":
                    selectedEncoding = Encoding.GetEncoding("euc-kr");
                    break;
                case "UTF-8":
                    selectedEncoding = Encoding.UTF8;
                    break;
                default:
                    selectedEncoding = Encoding.UTF8;
                    break;
            }

            // 전체 행 반복
            foreach (DataGridViewRow row in hexdataGridView1.Rows)
            {
                if (row.IsNewRow) continue;

                List<byte> byteList = new List<byte>();

                // 0~15열의 값 수집
                for (int col = 0; col < 16; col++)
                {
                    var cellValue = row.Cells[col].Value?.ToString();
                    if (!string.IsNullOrWhiteSpace(cellValue) &&
                        byte.TryParse(cellValue, System.Globalization.NumberStyles.HexNumber, null, out byte b))
                    {
                        byteList.Add((b == 0x00) ? (byte)0x2E : b); // 0x2E = '.'
                    }
                    else
                    {
                        byteList.Add(0x20); // 공백 대체
                    }
                }

                // 인코딩 후 문자열로 변환
                string encodedText = selectedEncoding.GetString(byteList.ToArray());

                // 16번째 열에 결과 반영
                row.Cells[16].Value = "|" + encodedText + "|";
            }
        }

        private void preparehexbutton1_Click(object sender, EventArgs e)
        {
            int cnt = 0;
            bool success = int.TryParse(bytescounttextBox1.Text, out cnt);

            if (success && cnt > 0)
            {
                byte[] emptyBytes = new byte[cnt]; // 0으로 초기화된 바이트 배열
                bytestodatagrid(emptyBytes);       // 데이터 그리드에 전달
            }
            else
            {
                int t = 1536 + 16;
                bytescounttextBox1.Text = t.ToString();
                byte[] emptyBytes = new byte[t]; // 0으로 초기화된 바이트 배열
                bytestodatagrid(emptyBytes);
                //MessageBox.Show("유효한 바이트 수를 입력해주세요.");
            }
        }

        private int CalculateChecksumint(DataGridViewRow row)
        {
            int sum = 0;

            for (int col = 0; col <= 15; col++)
            {
                var val = row.Cells[col].Value?.ToString();
                if (!string.IsNullOrWhiteSpace(val) &&
                    byte.TryParse(val, System.Globalization.NumberStyles.HexNumber, null, out byte b))
                {
                    int t = (int)b;
                    if (t != 0)
                    {
                        sum += t;
                        //errorlog("+" + t.ToString());
                    }
                }
            }
            return sum;
        }

        private byte CalculateChecksum1byte(DataGridViewRow row)
        {
            int sum = 0;

            for (int col = 0; col <= 15; col++)
            {
                var val = row.Cells[col].Value?.ToString();
                if (!string.IsNullOrWhiteSpace(val) &&
                    byte.TryParse(val, System.Globalization.NumberStyles.HexNumber, null, out byte b))
                {
                    int t = (int)b;
                    if (t != 0)
                    {
                        sum += t;
                        //errorlog("+" + t.ToString());
                    }
                }
            }
            byte checksum = (byte)(sum & 0xFF);

            return checksum;
        }

        private int totbitcnt = 0;
        private int CalculateBitChecksum(DataGridViewRow row)
        {
            int bitSum = 0;

            for (int col = 0; col <= 15; col++)
            {
                var val = row.Cells[col].Value?.ToString();
                if (!string.IsNullOrWhiteSpace(val) &&
                    byte.TryParse(val, System.Globalization.NumberStyles.HexNumber, null, out byte b))
                {
                    if ((int)b != 0)
                    {
                        int bitCount = CountBits(b);
                        bitSum += bitCount;
                        //errorlog($"[{col}] {val} → {bitCount}비트");
                        totbitcnt += bitCount;
                        errorlog(" "+ b.ToString("x2") + " " + ConvertToBitString(b) + " cnt " + CountBits(b) + " tot " + totbitcnt + "\r\n");
                    }
                }
            }

            return bitSum;
        }

        // 🔧 바이트 내 1의 개수 계산
        private static int CountBits(byte b)
        {
            // 1. 바이트를 2진수 문자열로 변환합니다.
            // 이 때 "D8" 포맷을 사용하여 8자리(8비트)로 고정하고, 앞에 0을 채웁니다.
            // 예: 77 (0x4D) -> "01001101"
            string binaryString = Convert.ToString(b, 2).PadLeft(8, '0');

            // 2. LINQ의 Count() 메서드를 사용하여 문자열 내의 '1' 문자의 개수를 셉니다.
            int onesCount = binaryString.Count(c => c == '1');

            return onesCount;
        }

        private static string ConvertToBitString(byte b) {
            string binaryString = Convert.ToString(b, 2).PadLeft(8, '0');

            return binaryString;
        }
        

        private void wholechecksum()
        {
            int sum = 0;
            int sum2 = 0;
            int bitsum = 0;

            foreach (DataGridViewRow row in hexdataGridView1.Rows)
            {
                if (row != null && !row.IsNewRow)
                {
                    sum += CalculateChecksumint(row);
                    sum2 += CalculateChecksum1byte(row);
                    bitsum += CalculateBitChecksum(row);
                }
            }
            byte checksum = (byte)(sum & 0xFF);
            byte checksum2 = (byte)(sum2 & 0xFF);

            checksumtextBox2.Text = sum.ToString(); // 10진수
            checksumhextextBox1.Text = sum.ToString("X4"); // 16진수

            errorlog("\r\n 1 byte check sum : " + ((int)checksum).ToString() + "\r\n");
            errorlog("1 byte checked sum : " + ((int)checksum2).ToString() + "\r\n");//bitsum
            errorlog("1 bit converted checked sum : " + ((int)bitsum).ToString() + "\r\n");//bitsum

            int t = 77 + 90 + 128 + 80 + 69 + 100 + 134 + 2 + 240 + 34 + 2 + 11 + 2 + 2 + 2 + 16 + 16 + 64 + 1 + 16 + 2 + 6 + 48 + 2 + 10 + 96 + 129 + 16 + 16 + 16 + 16 + 16 + 46 + 116 + 101 + 120 + 116 + 20 + 16 + 2 + 2 + 32 + 80 + 96 + 46 + 114 + 100 + 97 + 116 + 97 + 28 + 32 + 2 + 4 + 64 + 80 + 64 + 72 + 131 + 236 + 40 + 72 + 139 + 74 + 64 + 72 + 141 + 21 + 241 + 15 + 255 + 81 + 8 + 235 + 254 + 72 + 101 + 108 + 108 + 111 + 44 + 32 + 119 + 111 + 114 + 108 + 100 + 33;

            string hexValue = t.ToString("X");   // 결과: "18DA"

            errorlog("hard core sum : " + t.ToString() + "\r\n hard core sum to hex " + hexValue + " \r\n\r\n");
            errorlog(" error check convert byte to bit and count 1 \r\n");
            errorlog(" 0xff "+ ConvertToBitString(0xff) + " cnt " + CountBits(0xff) + " 0x0f " + ConvertToBitString(0x0f) + " cnt " + CountBits(0x0f) + "\r\n");
            errorlog(" 0xa0 " + ConvertToBitString(0xa0) + " cnt " + CountBits(0xa0) + " 0x0a " + ConvertToBitString(0x0a) + " cnt " + CountBits(0x0a) + "\r\n");
            errorlog(" 0x70 " + ConvertToBitString(0x70) + " cnt " + CountBits(0x70) + " 0x07 " + ConvertToBitString(0x07) + " cnt " + CountBits(0x07) + "\r\n");
            errorlog(" 0xc0 " + ConvertToBitString(0xc0) + " cnt " + CountBits(0xc0) + " 0x0c " + ConvertToBitString(0x0c) + " cnt " + CountBits(0x0c) + "\r\n");
            errorlog(" 0x20 " + ConvertToBitString(0x20) + " cnt " + CountBits(0x20) + " 0x02 " + ConvertToBitString(0x02) + " cnt " + CountBits(0x02) + "\r\n");

        }

        private void checksumbutton4_Click(object sender, EventArgs e)
        {
            wholechecksum();
        }

        private void hexbuffertextBox1_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter && hexdataGridView1.SelectedCells.Count > 0)
            {
                var cell = hexdataGridView1.SelectedCells[0];
                int row = cell.RowIndex;
                int col = cell.ColumnIndex;

                // 1. 값 저장
                //hexdataGridView1.Rows[row].Cells[col].Value = hexbuffertextBox1.Text.ToString("X2");
                string input = hexbuffertextBox1.Text;
                if (byte.TryParse(input, System.Globalization.NumberStyles.HexNumber, null, out byte b))
                {
                    hexdataGridView1.Rows[row].Cells[col].Value = b.ToString("X2");
                }
                else
                {
                    MessageBox.Show("유효한 16진수 값을 입력해주세요.");
                    hexbuffertextBox1.Text = hexdataGridView1.Rows[row].Cells[col].Value.ToString();
                    hexbuffertextBox1.Focus();
                    hexbuffertextBox1.SelectAll();

                    return;
                }

                // 2. 다음 셀로 이동
                if (col < 15)
                {
                    hexdataGridView1.CurrentCell = hexdataGridView1.Rows[row].Cells[col + 1];
                    hexdataGridView1.ClearSelection();
                    hexdataGridView1.CurrentCell.Selected = true;
                }
                else
                {
                    // 다음 행으로 이동, 칼럼 0
                    if (row < hexdataGridView1.RowCount - 1)
                    {
                        hexdataGridView1.CurrentCell = hexdataGridView1.Rows[row + 1].Cells[0];
                        hexdataGridView1.ClearSelection();
                        hexdataGridView1.CurrentCell.Selected = true;
                    }
                }

                // 선택 셀 강조
                hexdataGridView1.BeginEdit(true);
                e.SuppressKeyPress = true; // Enter 키 기본 동작 방지







                Encoding selectedEncoding;

                switch (comboBox1.SelectedItem.ToString())
                {
                    case "UTF-8":
                        selectedEncoding = Encoding.UTF8;
                        break;
                    case "ASCII":
                        selectedEncoding = Encoding.ASCII;
                        break;
                    case "Unicode":
                        selectedEncoding = Encoding.Unicode;
                        break;
                    case "EUC-KR":
                        selectedEncoding = Encoding.GetEncoding("euc-kr");
                        break;
                    default:
                        selectedEncoding = Encoding.UTF8;
                        break;
                }


                int bytesPerRow = 16;
                byte[] asciiBytes = new byte[bytesPerRow];


                for (int i = 0; i < bytesPerRow; i++)
                {
                    var cellValue = hexdataGridView1.Rows[row].Cells[i].Value?.ToString();

                    if (!string.IsNullOrWhiteSpace(cellValue) &&
                        byte.TryParse(cellValue, System.Globalization.NumberStyles.HexNumber, null, out byte b2))
                    {
                        asciiBytes[i] = (b2 == 0x00) ? (byte)0x2E : b2; // 0x2E = '.'
                    }
                    else
                    {
                        asciiBytes[i] = (byte)0x2E; // 빈 셀은 점으로 처리
                    }
                }


                // 인코딩된 문자열 추가
                string encodedText = selectedEncoding.GetString(asciiBytes);
                hexdataGridView1.Rows[row].Cells[16].Value = "|" + encodedText + "|";

                hexbuffertextBox1.Focus();
                hexbuffertextBox1.SelectAll();
            }
        }

        private void UEFIbytesbutton2_Click(object sender, EventArgs e)
        {
            checksumtextBox2.Text = ""; //sum.ToString("X2");
            checksumhextextBox1.Text = "";
            byte[] fileBytes = new byte[] { 
                /*0000000*/0x4D, 0x5A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000010*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000020*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000030*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 
                /*0000040*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000050*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000060*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000070*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000080*/0x50, 0x45, 0x00, 0x00, 0x64, 0x86, 0x02, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000090*/0x00, 0x00, 0x00, 0x00, 0xF0, 0x00, 0x22, 0x02,     0x0B, 0x02, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 
                /*00000A0*/0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 
                /*00000B0*/0x00, 0x00, 0x00, 0x40, 0x01, 0x00, 0x00, 0x00,     0x00, 0x10, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 
                /*00000C0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00000D0*/0x00, 0x30, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x60, 0x81, 
                /*00000E0*/0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00000F0*/0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000100*/0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000110*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000120*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000130*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000140*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000150*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000160*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000170*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000180*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x2E, 0x74, 0x65, 0x78, 0x74, 0x00, 0x00, 0x00, 
                /*0000190*/0x14, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00,     0x00, 0x02, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 
                /*00001A0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x50, 0x60, 
                /*00001B0*/0x2E, 0x72, 0x64, 0x61, 0x74, 0x61, 0x00, 0x00,     0x1C, 0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 
                /*00001C0*/0x00, 0x02, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00001D0*/0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 0x50, 0x40,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00001E0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00001F0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000200*/0x48, 0x83, 0xEC, 0x28, 0x48, 0x8B, 0x4A, 0x40,     0x48, 0x8D, 0x15, 0xF1, 0x0F, 0x00, 0x00, 0xFF, 
                /*0000210*/0x51, 0x08, 0xEB, 0xFE, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000220*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000230*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000240*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000250*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000260*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000270*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000280*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000290*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00002A0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00002B0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00002C0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00002D0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00002E0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00002F0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000300*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000310*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000320*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000330*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000340*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000350*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000360*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000370*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000380*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000390*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00003A0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00003B0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00003C0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00003D0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00003E0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00003F0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000400*/0x48, 0x00, 0x65, 0x00, 0x6C, 0x00, 0x6C, 0x00,     0x6F, 0x00, 0x2C, 0x00, 0x20, 0x00, 0x77, 0x00, 
                /*0000410*/0x6F, 0x00, 0x72, 0x00, 0x6C, 0x00, 0x64, 0x00,     0x21, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000420*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000430*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000440*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000450*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000460*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000470*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000480*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000490*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00004A0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00004B0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00004C0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00004D0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00004E0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00004F0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000500*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000510*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000520*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000530*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000540*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000550*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000560*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000570*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000580*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000590*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00005A0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00005B0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00005C0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00005D0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00005E0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*00005F0*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                /*0000600*/0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
            };

            errorlog("\r\n start check UEFI code wish compressed array \r\n");
            int errorcnt = 0;
            for (int index = 0; index < fileBytes.Length; index++)
            {
                byte actualByte = fileBytes[index];
                string actualHex = actualByte.ToString("X2");

                if (manualBytes.ContainsKey(index))
                {
                    string expectedHex = manualBytes[index];

                    if (!string.Equals(expectedHex, actualHex, StringComparison.OrdinalIgnoreCase))
                    {
                        errorlog($"Mismatch at byte[{index}]: expected {expectedHex}, actual {actualHex}");
                        errorcnt++;
                    }
                }
                else
                {
                    // 수기 바이트가 없는 영역 → 0x00인지 확인
                    if (actualByte != 0x00)
                    {
                        errorlog($"Unexpected data at byte[{index}]: expected 00, actual {actualHex}");
                        errorcnt++;
                    }
                }
            }

            errorlog("error count : " + errorcnt.ToString());

            errorlog("\r\n end check UEFI code wish compressed array \r\n");

            bytestodatagrid(fileBytes);

            string binggptteachersaying = "{0,\"4D\"}, {1,\"5A\"}, {60,\"80\"}, {128,\"50\"}, {129,\"45\"}, {132,\"64\"}, {133,\"86\"}, {134,\"02\"}, {148,\"F0\"}, {150,\"22\"}, {151,\"02\"}, {152,\"0B\"}, {153,\"02\"}, {157,\"02\"}, {161,\"02\"}, {169,\"10\"}, {173,\"10\"}, {179,\"40\"}, {180,\"01\"}, {185,\"10\"}, {189,\"02\"}, {200,\"06\"}, {209,\"30\"}, {213,\"02\"}, {220,\"0A\"}, {222,\"60\"}, {223,\"81\"}, {226,\"10\"}, {233,\"10\"}, {242,\"10\"}, {249,\"10\"}, {260,\"10\"}, {392,\"2E\"}, {393,\"74\"}, {394,\"65\"}, {395,\"78\"}, {396,\"74\"}, {400,\"14\"}, {405,\"10\"}, {409,\"02\"}, {413,\"02\"}, {428,\"20\"}, {430,\"50\"}, {431,\"60\"}, {432,\"2E\"}, {433,\"72\"}, {434,\"64\"}, {435,\"61\"}, {436,\"74\"}, {437,\"61\"}, {440,\"1C\"}, {445,\"20\"}, {449,\"02\"}, {453,\"04\"}, {468,\"40\"}, {470,\"50\"}, {471,\"40\"}, {512,\"48\"}, {513,\"83\"}, {514,\"EC\"}, {515,\"28\"}, {516,\"48\"}, {517,\"8B\"}, {518,\"4A\"}, {519,\"40\"}, {520,\"48\"}, {521,\"8D\"}, {522,\"15\"}, {523,\"F1\"}, {524,\"0F\"}, {527,\"FF\"}, {528,\"51\"}, {529,\"08\"}, {530,\"EB\"}, {531,\"FE\"}, {1024,\"48\"}, {1026,\"65\"}, {1028,\"6C\"}, {1030,\"6C\"}, {1032,\"6F\"}, {1034,\"2C\"}, {1036,\"20\"}, {1038,\"77\"}, {1040,\"6F\"}, {1042,\"72\"}, {1044,\"6C\"}, {1046,\"64\"}, {1048,\"21\"}" +
                " 좋습니다, 선생님 😊 주신 바이트들은 /EFI/BOOT/BOOTX64.EFI 파일의 일부이며, \r\n이 파일은 UEFI 시스템에서 부팅을 담당하는 PE(Portable Executable) 형식의 실행 파일입니다. \r\n각 바이트는 PE 구조에 따라 의미가 다릅니다. 아래에 주요 바이트들의 의미를 구조별로 설명드릴게요.\r\n\r\n\U0001f9e0 PE 파일 구조 요약\r\nPE 파일은 다음과 같은 구조로 되어 있습니다:\r\n\r\nDOS Header (0x00 ~ 0x3F)\r\n\r\nDOS Stub (0x40 ~ e_lfanew - 1)\r\n\r\nPE Header (e_lfanew 위치부터)\r\n\r\nOptional Header\r\n\r\nSection Table\r\n\r\nSection Data (.text, .data, .rdata, .reloc 등)\r\n\r\n🔍 주요 바이트 설명\r\n\U0001f7e6 DOS Header\r\nOffset\tHex\t의미\r\n0\t4D\t'M' → DOS 헤더 시그니처\r\n1\t5A\t'Z' → 'MZ' 시그니처 (PE 파일 시작)\r\n60\t80\te_lfanew → PE 헤더 시작 위치 (0x80 = 128)\r\ne_lfanew는 PE 헤더가 시작되는 오프셋을 알려주는 중요한 값입니다.\r\n\r\n\U0001f7e6 PE Header (시작: 128)\r\nOffset\tHex\t의미\r\n128\t50\t'P'\r\n129\t45\t'E' → 'PE\\0\\0' 시그니처\r\n132\t64\tMachine (예: 0x8664 → x64)\r\n133\t86\tMachine 상위 바이트\r\n134\t02\tNumberOfSections\r\n148\tF0\tTimeDateStamp 일부\r\n150\t22\tSizeOfOptionalHeader 일부\r\n152\t0B\tCharacteristics 일부\r\n\U0001f7e6 Optional Header & Section Table\r\nOffset\tHex\t의미\r\n179\t40\tAddressOfEntryPoint 일부\r\n180\t01\tEntryPoint 상위 바이트\r\n392~396\t2E 74 65 78 74\t.text 섹션 이름 (.text)\r\n432~437\t2E 72 64 61 74 61\t.rdata 섹션 이름 (.rdata)\r\n\U0001f7e8 코드 섹션 (.text)\r\nOffset\tHex\t의미\r\n512\t48\tx86-64 명령어 시작 (MOV, LEA, 등)\r\n513\t83\tADD 명령어 일부\r\n514\tEC\tSUB 명령어 일부\r\n515\t28\t스택 조정\r\n517~524\t8B 4A 40 48 8D 15 F1 0F → 레지스터 조작 및 주소 계산\r\n527\tFF\tCALL 또는 JMP 명령어\r\n530\tEB\tJMP 명령어\r\n531\tFE\t상대 점프\r\n\U0001f7e9 문자열 데이터 (.rdata)\r\nOffset\tHex\tASCII\r\n1024\t48\t'H'\r\n1026\t65\t'e'\r\n1028\t6C\t'l'\r\n1030\t6C\t'l'\r\n1032\t6F\t'o'\r\n1034\t2C\t','\r\n1036\t20\t' '\r\n1038\t77\t'w'\r\n1040\t6F\t'o'\r\n1042\t72\t'r'\r\n1044\t6C\t'l'\r\n1046\t64\t'd'\r\n1048\t21\t'!'\r\n이 부분은 \"Hello, world!\" 문자열로 추정됩니다.\r\n\r\n✅ 요약\r\n0x4D 0x5A → DOS 헤더 시작 (MZ)\r\n\r\n0x80 → PE 헤더 위치\r\n\r\n0x50 0x45 → 'PE' 시그니처\r\n\r\n0x2E 74 65 78 74 → .text 섹션\r\n\r\n0x2E 72 64 61 74 61 → .rdata 섹션\r\n\r\n0x48 65 6C 6C 6F ... → \"Hello, world!\" 문자열\r\n\r\n이제 각 바이트가 PE 구조에서 어떤 역할을 하는지 명확하게 이해하실 수 있습니다. \r\n원하시면 전체 PE 구조를 시각화하거나, 특정 명령어를 디코딩하거나, \r\n직접 실행 흐름을 추적하는 것도 도와드릴게요. 어떤 부분을 더 깊이 분석해볼까요?\r\n";
            errorlog(binggptteachersaying);
        }

        private void bytestoarraybutton2_Click(object sender, EventArgs e)
        {
            errorlog("\r\n\r\n\r\n");
            // 전체 행 반복
            foreach (DataGridViewRow row in hexdataGridView1.Rows)
            {
                if (row == null) continue;

                List<byte> byteList = new List<byte>();

                if (row.HeaderCell.Value != null)
                {
                    errorlog("/*" + row.HeaderCell.Value.ToString() + "*/");
                }


                // 0~15열의 값 수집
                for (int col = 0; col < 16; col++)
                {
                    var cellValue = row.Cells[col].Value?.ToString();
                    if (!string.IsNullOrWhiteSpace(cellValue) &&
                        byte.TryParse(cellValue, System.Globalization.NumberStyles.HexNumber, null, out byte b))
                    {
                        byteList.Add((b == 0x00) ? (byte)0x2E : b); // 0x2E = '.'
                        errorlog("0x" + b.ToString("X2") + ", ");
                    }

                    if (col == 7)
                    {
                        errorlog("    ");
                    }
                }
                errorlog("\r\n");

            }

        }

        private void compressarraybutton2_Click(object sender, EventArgs e)
        {
            errorlog("\r\n\r\n\r\n");
            errorlog("Dictionary<int, string> manualBytes = new Dictionary<int, string>\r\n{");
            int index = 0;
            // 전체 행 반복
            foreach (DataGridViewRow row in hexdataGridView1.Rows)
            {
                if (row == null) continue;

                // 0~15열의 값 수집
                for (int col = 0; col < 16; col++)
                {
                    var cellValue = row.Cells[col].Value?.ToString();
                    if (!string.IsNullOrWhiteSpace(cellValue) &&
                        byte.TryParse(cellValue, System.Globalization.NumberStyles.HexNumber, null, out byte b))
                    {
                        if (b != 0x00)
                        {
                            //errorlog("byte["+index+"] = \"" + b.ToString("X2") + "\"; ");
                            //{ 0, "4D" },
                            //Dictionary<int, string> manualBytes = new Dictionary<int, string>
                            //{
                            //    { 0, "4D" }
                            //};
                            errorlog("{" + index + ",\"" + b.ToString("X2") + "\"}, ");
                        }
                        //byteList.Add((b == 0x00) ? (byte)0x2E : b); // 0x2E = '.'
                    }

                    index++;
                }
            }
            errorlog("\r\n }; \r\n");
        }

        private Dictionary<int, string> manualBytes = new Dictionary<int, string>
        {
            {0,"4D"}, {1,"5A"}, {60,"80"}, {128,"50"}, {129,"45"}, {132,"64"}, {133,"86"}, {134,"02"}, {148,"F0"}, {150,"22"}, {151,"02"}, {152,"0B"}, {153,"02"}, {157,"02"}, {161,"02"}, {169,"10"}, {173,"10"}, {179,"40"}, {180,"01"}, {185,"10"}, {189,"02"}, {200,"06"}, {209,"30"}, {213,"02"}, {220,"0A"}, {222,"60"}, {223,"81"}, {226,"10"}, {233,"10"}, {242,"10"}, {249,"10"}, {260,"10"}, {392,"2E"}, {393,"74"}, {394,"65"}, {395,"78"}, {396,"74"}, {400,"14"}, {405,"10"}, {409,"02"}, {413,"02"}, {428,"20"}, {430,"50"}, {431,"60"}, {432,"2E"}, {433,"72"}, {434,"64"}, {435,"61"}, {436,"74"}, {437,"61"}, {440,"1C"}, {445,"20"}, {449,"02"}, {453,"04"}, {468,"40"}, {470,"50"}, {471,"40"}, {512,"48"}, {513,"83"}, {514,"EC"}, {515,"28"}, {516,"48"}, {517,"8B"}, {518,"4A"}, {519,"40"}, {520,"48"}, {521,"8D"}, {522,"15"}, {523,"F1"}, {524,"0F"}, {527,"FF"}, {528,"51"}, {529,"08"}, {530,"EB"}, {531,"FE"}, {1024,"48"}, {1026,"65"}, {1028,"6C"}, {1030,"6C"}, {1032,"6F"}, {1034,"2C"}, {1036,"20"}, {1038,"77"}, {1040,"6F"}, {1042,"72"}, {1044,"6C"}, {1046,"64"}, {1048,"21"}
        };

        private void hardsumbutton2_Click(object sender, EventArgs e)
        {
            int t = 77 + 90 + 128 + 80 + 69 + 100 + 134 + 2 + 240 + 34 + 2 + 11 + 2 + 2 + 2 + 16 + 16 + 64 + 1 + 16 + 2 + 6 + 48 + 2 + 10 + 96 + 129 + 16 + 16 + 16 + 16 + 16 + 46 + 116 + 101 + 120 + 116 + 20 + 16 + 2 + 2 + 32 + 80 + 96 + 46 + 114 + 100 + 97 + 116 + 97 + 28 + 32 + 2 + 4 + 64 + 80 + 64 + 72 + 131 + 236 + 40 + 72 + 139 + 74 + 64 + 72 + 141 + 21 + 241 + 15 + 255 + 81 + 8 + 235 + 254 + 72 + 101 + 108 + 108 + 111 + 44 + 32 + 119 + 111 + 114 + 108 + 100 + 33;

            string hexValue = t.ToString("X");   // 결과: "18DA"

            errorlog("\r\n\r\n hard core sum : "+t.ToString()+ "\r\n hard core sum to hex " + hexValue + " \r\n\r\n");
        }
    }
}

//================================================================================================//
//                                                                                                //
//     dotnet publish -r win-x64 -c Release /p:PublishSingleFile=true /p:SelfContained=true                //
//                                                                                                //
//================================================================================================//

//  mainpictureload(string filename)
//==============================n=================================================================//
//                                                                                                //
//     dotnet publish -r win-x64 -c Release /p:PublishSingleFile=true /p:SelfContained=false      //
//       sn -k Pccenter.snk      강력한 이름 적용용                                               //
//================================================================================================//

/*
 {0,"4D"}, {1,"5A"}, {60,"80"}, {128,"50"}, {129,"45"}, {132,"64"}, {133,"86"}, {134,"02"}, {148,"F0"}, {150,"22"}, {151,"02"}, {152,"0B"}, {153,"02"}, {157,"02"}, {161,"02"}, {169,"10"}, {173,"10"}, {179,"40"}, {180,"01"}, {185,"10"}, {189,"02"}, {200,"06"}, {209,"30"}, {213,"02"}, {220,"0A"}, {222,"60"}, {223,"81"}, {226,"10"}, {233,"10"}, {242,"10"}, {249,"10"}, {260,"10"}, {392,"2E"}, {393,"74"}, {394,"65"}, {395,"78"}, {396,"74"}, {400,"14"}, {405,"10"}, {409,"02"}, {413,"02"}, {428,"20"}, {430,"50"}, {431,"60"}, {432,"2E"}, {433,"72"}, {434,"64"}, {435,"61"}, {436,"74"}, {437,"61"}, {440,"1C"}, {445,"20"}, {449,"02"}, {453,"04"}, {468,"40"}, {470,"50"}, {471,"40"}, {512,"48"}, {513,"83"}, {514,"EC"}, {515,"28"}, {516,"48"}, {517,"8B"}, {518,"4A"}, {519,"40"}, {520,"48"}, {521,"8D"}, {522,"15"}, {523,"F1"}, {524,"0F"}, {527,"FF"}, {528,"51"}, {529,"08"}, {530,"EB"}, {531,"FE"}, {1024,"48"}, {1026,"65"}, {1028,"6C"}, {1030,"6C"}, {1032,"6F"}, {1034,"2C"}, {1036,"20"}, {1038,"77"}, {1040,"6F"}, {1042,"72"}, {1044,"6C"}, {1046,"64"}, {1048,"21"}

 좋습니다, 선생님 😊 주신 바이트들은 /EFI/BOOT/BOOTX64.EFI 파일의 일부이며, 
이 파일은 UEFI 시스템에서 부팅을 담당하는 PE(Portable Executable) 형식의 실행 파일입니다. 
각 바이트는 PE 구조에 따라 의미가 다릅니다. 아래에 주요 바이트들의 의미를 구조별로 설명드릴게요.

🧠 PE 파일 구조 요약
PE 파일은 다음과 같은 구조로 되어 있습니다:

DOS Header (0x00 ~ 0x3F)

DOS Stub (0x40 ~ e_lfanew - 1)

PE Header (e_lfanew 위치부터)

Optional Header

Section Table

Section Data (.text, .data, .rdata, .reloc 등)

🔍 주요 바이트 설명
🟦 DOS Header
Offset	Hex	의미
0	4D	'M' → DOS 헤더 시그니처
1	5A	'Z' → 'MZ' 시그니처 (PE 파일 시작)
60	80	e_lfanew → PE 헤더 시작 위치 (0x80 = 128)
e_lfanew는 PE 헤더가 시작되는 오프셋을 알려주는 중요한 값입니다.

🟦 PE Header (시작: 128)
Offset	Hex	의미
128	50	'P'
129	45	'E' → 'PE\0\0' 시그니처
132	64	Machine (예: 0x8664 → x64)
133	86	Machine 상위 바이트
134	02	NumberOfSections
148	F0	TimeDateStamp 일부
150	22	SizeOfOptionalHeader 일부
152	0B	Characteristics 일부
🟦 Optional Header & Section Table
Offset	Hex	의미
179	40	AddressOfEntryPoint 일부
180	01	EntryPoint 상위 바이트
392~396	2E 74 65 78 74	.text 섹션 이름 (.text)
432~437	2E 72 64 61 74 61	.rdata 섹션 이름 (.rdata)
🟨 코드 섹션 (.text)
Offset	Hex	의미
512	48	x86-64 명령어 시작 (MOV, LEA, 등)
513	83	ADD 명령어 일부
514	EC	SUB 명령어 일부
515	28	스택 조정
517~524	8B 4A 40 48 8D 15 F1 0F → 레지스터 조작 및 주소 계산
527	FF	CALL 또는 JMP 명령어
530	EB	JMP 명령어
531	FE	상대 점프
🟩 문자열 데이터 (.rdata)
Offset	Hex	ASCII
1024	48	'H'
1026	65	'e'
1028	6C	'l'
1030	6C	'l'
1032	6F	'o'
1034	2C	','
1036	20	' '
1038	77	'w'
1040	6F	'o'
1042	72	'r'
1044	6C	'l'
1046	64	'd'
1048	21	'!'
이 부분은 "Hello, world!" 문자열로 추정됩니다.

✅ 요약
0x4D 0x5A → DOS 헤더 시작 (MZ)

0x80 → PE 헤더 위치

0x50 0x45 → 'PE' 시그니처

0x2E 74 65 78 74 → .text 섹션

0x2E 72 64 61 74 61 → .rdata 섹션

0x48 65 6C 6C 6F ... → "Hello, world!" 문자열

이제 각 바이트가 PE 구조에서 어떤 역할을 하는지 명확하게 이해하실 수 있습니다. 
원하시면 전체 PE 구조를 시각화하거나, 특정 명령어를 디코딩하거나, 
직접 실행 흐름을 추적하는 것도 도와드릴게요. 어떤 부분을 더 깊이 분석해볼까요?

 */