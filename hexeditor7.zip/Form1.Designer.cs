﻿namespace hexeditor7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            openfilebutton1 = new Button();
            hexbuffertextBox1 = new TextBox();
            savefilebutton3 = new Button();
            checksumbutton4 = new Button();
            checksumtextBox2 = new TextBox();
            hexdataGridView1 = new DataGridView();
            addresstextBox2 = new TextBox();
            preparehexbutton1 = new Button();
            adpictureBox1 = new PictureBox();
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            richTextBox1 = new RichTextBox();
            realipaddrtxt = new Label();
            emailtxt = new Label();
            cellltextBox11 = new Label();
            activetimelabel25 = new Label();
            comboBox1 = new ComboBox();
            bytesindextextBox1 = new TextBox();
            logtogglebutton2 = new Button();
            selfdllcheckbutton2 = new Button();
            modifydatabutton2 = new Button();
            bytescounttextBox1 = new TextBox();
            checksumhextextBox1 = new TextBox();
            UEFIbytesbutton2 = new Button();
            bytestoarraybutton2 = new Button();
            compressarraybutton2 = new Button();
            hardsumbutton2 = new Button();
            ((System.ComponentModel.ISupportInitialize)hexdataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)adpictureBox1).BeginInit();
            SuspendLayout();
            // 
            // openfilebutton1
            // 
            openfilebutton1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            openfilebutton1.Location = new Point(813, 70);
            openfilebutton1.Name = "openfilebutton1";
            openfilebutton1.Size = new Size(100, 23);
            openfilebutton1.TabIndex = 0;
            openfilebutton1.Text = "Open File";
            openfilebutton1.UseVisualStyleBackColor = true;
            openfilebutton1.Click += openfilebutton1_Click;
            // 
            // hexbuffertextBox1
            // 
            hexbuffertextBox1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            hexbuffertextBox1.Location = new Point(144, 12);
            hexbuffertextBox1.Name = "hexbuffertextBox1";
            hexbuffertextBox1.Size = new Size(295, 23);
            hexbuffertextBox1.TabIndex = 1;
            hexbuffertextBox1.KeyDown += hexbuffertextBox1_KeyDown;
            // 
            // savefilebutton3
            // 
            savefilebutton3.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            savefilebutton3.Location = new Point(813, 99);
            savefilebutton3.Name = "savefilebutton3";
            savefilebutton3.Size = new Size(100, 23);
            savefilebutton3.TabIndex = 4;
            savefilebutton3.Text = "Save File";
            savefilebutton3.UseVisualStyleBackColor = true;
            savefilebutton3.Click += savefilebutton3_Click;
            // 
            // checksumbutton4
            // 
            checksumbutton4.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            checksumbutton4.Location = new Point(813, 134);
            checksumbutton4.Name = "checksumbutton4";
            checksumbutton4.Size = new Size(100, 23);
            checksumbutton4.TabIndex = 5;
            checksumbutton4.Text = "Check Sum";
            checksumbutton4.UseVisualStyleBackColor = true;
            checksumbutton4.Click += checksumbutton4_Click;
            // 
            // checksumtextBox2
            // 
            checksumtextBox2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            checksumtextBox2.Location = new Point(813, 163);
            checksumtextBox2.Name = "checksumtextBox2";
            checksumtextBox2.PlaceholderText = "check sum int";
            checksumtextBox2.Size = new Size(100, 23);
            checksumtextBox2.TabIndex = 6;
            // 
            // hexdataGridView1
            // 
            hexdataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            hexdataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            hexdataGridView1.Location = new Point(12, 41);
            hexdataGridView1.Name = "hexdataGridView1";
            hexdataGridView1.RowHeadersWidth = 97;
            hexdataGridView1.SelectionMode = DataGridViewSelectionMode.CellSelect;
            hexdataGridView1.Size = new Size(795, 332);
            hexdataGridView1.TabIndex = 9;
            hexdataGridView1.SelectionChanged += hexdataGridView1_SelectionChanged;
            // 
            // addresstextBox2
            // 
            addresstextBox2.Location = new Point(12, 12);
            addresstextBox2.Name = "addresstextBox2";
            addresstextBox2.Size = new Size(81, 23);
            addresstextBox2.TabIndex = 10;
            // 
            // preparehexbutton1
            // 
            preparehexbutton1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            preparehexbutton1.Location = new Point(813, 41);
            preparehexbutton1.Name = "preparehexbutton1";
            preparehexbutton1.Size = new Size(100, 23);
            preparehexbutton1.TabIndex = 11;
            preparehexbutton1.Text = "Prepare hexes";
            preparehexbutton1.UseVisualStyleBackColor = true;
            preparehexbutton1.Click += preparehexbutton1_Click;
            // 
            // adpictureBox1
            // 
            adpictureBox1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            adpictureBox1.Location = new Point(12, 380);
            adpictureBox1.Name = "adpictureBox1";
            adpictureBox1.Size = new Size(270, 50);
            adpictureBox1.TabIndex = 12;
            adpictureBox1.TabStop = false;
            adpictureBox1.Click += adpictureBox1_Click;
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            button1.Location = new Point(288, 380);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 13;
            button1.Text = "Ad Change";
            button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            label1.AutoSize = true;
            label1.Font = new Font("맑은 고딕", 17F);
            label1.Location = new Point(369, 380);
            label1.Name = "label1";
            label1.Size = new Size(224, 31);
            label1.TabIndex = 14;
            label1.Text = "www.CoreaApp.com";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            label2.AutoSize = true;
            label2.Location = new Point(301, 415);
            label2.Name = "label2";
            label2.Size = new Size(278, 15);
            label2.TabIndex = 15;
            label2.Text = "This program is free software Coreaapp ad License";
            // 
            // richTextBox1
            // 
            richTextBox1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            richTextBox1.Location = new Point(12, 436);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(901, 87);
            richTextBox1.TabIndex = 16;
            richTextBox1.Text = "16 개씩 Hex 로 hexes 에 컨탠츠에 인코딩한 값을";
            // 
            // realipaddrtxt
            // 
            realipaddrtxt.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            realipaddrtxt.AutoSize = true;
            realipaddrtxt.Location = new Point(813, 319);
            realipaddrtxt.Name = "realipaddrtxt";
            realipaddrtxt.Size = new Size(39, 15);
            realipaddrtxt.TabIndex = 17;
            realipaddrtxt.Text = "label3";
            // 
            // emailtxt
            // 
            emailtxt.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            emailtxt.AutoSize = true;
            emailtxt.Location = new Point(813, 339);
            emailtxt.Name = "emailtxt";
            emailtxt.Size = new Size(39, 15);
            emailtxt.TabIndex = 18;
            emailtxt.Text = "label3";
            // 
            // cellltextBox11
            // 
            cellltextBox11.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            cellltextBox11.AutoSize = true;
            cellltextBox11.Location = new Point(813, 358);
            cellltextBox11.Name = "cellltextBox11";
            cellltextBox11.Size = new Size(39, 15);
            cellltextBox11.TabIndex = 19;
            cellltextBox11.Text = "label3";
            // 
            // activetimelabel25
            // 
            activetimelabel25.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            activetimelabel25.AutoSize = true;
            activetimelabel25.Location = new Point(813, 304);
            activetimelabel25.Name = "activetimelabel25";
            activetimelabel25.Size = new Size(14, 15);
            activetimelabel25.TabIndex = 20;
            activetimelabel25.Text = "0";
            // 
            // comboBox1
            // 
            comboBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(555, 12);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(150, 23);
            comboBox1.TabIndex = 21;
            comboBox1.Text = "content Encoder";
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // bytesindextextBox1
            // 
            bytesindextextBox1.Location = new Point(99, 12);
            bytesindextextBox1.Name = "bytesindextextBox1";
            bytesindextextBox1.Size = new Size(39, 23);
            bytesindextextBox1.TabIndex = 22;
            // 
            // logtogglebutton2
            // 
            logtogglebutton2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            logtogglebutton2.Location = new Point(813, 407);
            logtogglebutton2.Name = "logtogglebutton2";
            logtogglebutton2.Size = new Size(100, 23);
            logtogglebutton2.TabIndex = 23;
            logtogglebutton2.Text = "Log toggle";
            logtogglebutton2.UseVisualStyleBackColor = true;
            logtogglebutton2.Click += logtogglebutton2_Click;
            // 
            // selfdllcheckbutton2
            // 
            selfdllcheckbutton2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            selfdllcheckbutton2.Location = new Point(813, 380);
            selfdllcheckbutton2.Name = "selfdllcheckbutton2";
            selfdllcheckbutton2.Size = new Size(100, 23);
            selfdllcheckbutton2.TabIndex = 24;
            selfdllcheckbutton2.Text = "Self Dll check";
            selfdllcheckbutton2.UseVisualStyleBackColor = true;
            selfdllcheckbutton2.Click += selfdllcheckbutton2_Click;
            // 
            // modifydatabutton2
            // 
            modifydatabutton2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            modifydatabutton2.Location = new Point(445, 12);
            modifydatabutton2.Name = "modifydatabutton2";
            modifydatabutton2.Size = new Size(104, 23);
            modifydatabutton2.TabIndex = 25;
            modifydatabutton2.Text = "Modify Data";
            modifydatabutton2.UseVisualStyleBackColor = true;
            modifydatabutton2.Click += modifydatabutton2_Click;
            // 
            // bytescounttextBox1
            // 
            bytescounttextBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            bytescounttextBox1.Location = new Point(813, 12);
            bytescounttextBox1.Name = "bytescounttextBox1";
            bytescounttextBox1.PlaceholderText = "bytes count";
            bytescounttextBox1.Size = new Size(100, 23);
            bytescounttextBox1.TabIndex = 26;
            // 
            // checksumhextextBox1
            // 
            checksumhextextBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            checksumhextextBox1.Location = new Point(813, 192);
            checksumhextextBox1.Name = "checksumhextextBox1";
            checksumhextextBox1.PlaceholderText = "check sum hex";
            checksumhextextBox1.Size = new Size(100, 23);
            checksumhextextBox1.TabIndex = 27;
            // 
            // UEFIbytesbutton2
            // 
            UEFIbytesbutton2.Location = new Point(711, 12);
            UEFIbytesbutton2.Name = "UEFIbytesbutton2";
            UEFIbytesbutton2.Size = new Size(96, 23);
            UEFIbytesbutton2.TabIndex = 28;
            UEFIbytesbutton2.Text = "UEFI Bytes";
            UEFIbytesbutton2.UseVisualStyleBackColor = true;
            UEFIbytesbutton2.Click += UEFIbytesbutton2_Click;
            // 
            // bytestoarraybutton2
            // 
            bytestoarraybutton2.Location = new Point(813, 221);
            bytestoarraybutton2.Name = "bytestoarraybutton2";
            bytestoarraybutton2.Size = new Size(100, 23);
            bytestoarraybutton2.TabIndex = 29;
            bytestoarraybutton2.Text = "Bytes to array";
            bytestoarraybutton2.UseVisualStyleBackColor = true;
            bytestoarraybutton2.Click += bytestoarraybutton2_Click;
            // 
            // compressarraybutton2
            // 
            compressarraybutton2.Location = new Point(813, 250);
            compressarraybutton2.Name = "compressarraybutton2";
            compressarraybutton2.Size = new Size(100, 23);
            compressarraybutton2.TabIndex = 30;
            compressarraybutton2.Text = "compress array";
            compressarraybutton2.UseVisualStyleBackColor = true;
            compressarraybutton2.Click += compressarraybutton2_Click;
            // 
            // hardsumbutton2
            // 
            hardsumbutton2.Location = new Point(813, 278);
            hardsumbutton2.Name = "hardsumbutton2";
            hardsumbutton2.Size = new Size(75, 23);
            hardsumbutton2.TabIndex = 31;
            hardsumbutton2.Text = "hard sum";
            hardsumbutton2.UseVisualStyleBackColor = true;
            hardsumbutton2.Click += hardsumbutton2_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(915, 528);
            Controls.Add(hardsumbutton2);
            Controls.Add(compressarraybutton2);
            Controls.Add(bytestoarraybutton2);
            Controls.Add(UEFIbytesbutton2);
            Controls.Add(checksumhextextBox1);
            Controls.Add(bytescounttextBox1);
            Controls.Add(modifydatabutton2);
            Controls.Add(selfdllcheckbutton2);
            Controls.Add(logtogglebutton2);
            Controls.Add(bytesindextextBox1);
            Controls.Add(comboBox1);
            Controls.Add(activetimelabel25);
            Controls.Add(cellltextBox11);
            Controls.Add(emailtxt);
            Controls.Add(realipaddrtxt);
            Controls.Add(richTextBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(adpictureBox1);
            Controls.Add(preparehexbutton1);
            Controls.Add(addresstextBox2);
            Controls.Add(hexdataGridView1);
            Controls.Add(checksumtextBox2);
            Controls.Add(checksumbutton4);
            Controls.Add(savefilebutton3);
            Controls.Add(hexbuffertextBox1);
            Controls.Add(openfilebutton1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "HEX BURSTOR UEFI HELLO WORLD amazing";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)hexdataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)adpictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button openfilebutton1;
        private TextBox hexbuffertextBox1;
        private Button savefilebutton3;
        private Button checksumbutton4;
        private TextBox checksumtextBox2;
        private DataGridView hexdataGridView1;
        private TextBox addresstextBox2;
        private Button preparehexbutton1;
        public PictureBox adpictureBox1;
        private Button button1;
        private Label label1;
        private Label label2;
        private RichTextBox richTextBox1;
        public Label realipaddrtxt;
        public Label emailtxt;
        public Label cellltextBox11;
        public Label activetimelabel25;
        private ComboBox comboBox1;
        private TextBox bytesindextextBox1;
        private Button logtogglebutton2;
        private Button selfdllcheckbutton2;
        private Button modifydatabutton2;
        private TextBox bytescounttextBox1;
        private TextBox checksumhextextBox1;
        private Button UEFIbytesbutton2;
        private Button bytestoarraybutton2;
        private Button compressarraybutton2;
        private Button hardsumbutton2;
    }
}
