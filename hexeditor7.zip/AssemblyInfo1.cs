using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

// 이와 같은 SDK 스타일 프로젝트에서는 이 파일에 지금까지 정의된 여러 어셈블리 특성이 이제 빌드 중에 자동으로 추가되고 프로젝트 속성에 정의된
// 값으로 채워집니다. 포함된 특성에 대한 자세한 내용과 이 프로세스를 사용자 지정하는 방법에 대해서는 https://aka.ms/assembly-info-properties를
// 참조하세요.


// ComVisible을 false로 설정하면 이 어셈블리의 형식이 COM 구성 요소에 표시되지 않습니다.  COM에서 이 어셈블리의 형식에 액세스하려면
// 해당 형식에 대해 ComVisible 특성을 true로 설정하세요.

[assembly: ComVisible(false)]

// 이 프로젝트가 COM에 노출되는 경우 다음 GUID는 typelib의 ID를 나타냅니다.

[assembly: Guid("036282d3-403b-4ab1-8746-03ecf4cafd06")]


[assembly: AssemblyTitle("Hexeditor 7")]
[assembly: AssemblyDescription("Hexeditor Tool")]
[assembly: AssemblyProduct("Hexeditor 7")]
[assembly: AssemblyCompany("coreaapp.com")]
[assembly: AssemblyCopyright("Copyright © coreaapp.com 2025")]
[assembly: AssemblyTrademark("Hexeditor7")]

//[assembly: AssemblyCulture("en-US")] // 미국 영어 문화권 설정

[assembly: AssemblyVersion("0.0.1.0")]
[assembly: AssemblyFileVersion("0.0.1.0")]
[assembly: AssemblyInformationalVersion("0.0.1.0")]
[assembly: AssemblyConfiguration("Release")] // 또는 "Debug"
[assembly: SupportedOSPlatform("windows")]